# AdForce — Техническая спецификация

## Зависимости

| Пакет | Версия | Назначение |
|-------|--------|------------|
| three | ^0.170.0 | WebGL starfield shader |
| @react-three/fiber | ^8.17.0 | React-обертка для Three.js |
| @react-three/drei | ^9.114.0 | Вспомогательные R3F компоненты |
| gsap | ^3.12.0 | Анимации, ScrollTrigger, timeline |
| lenis | ^1.1.0 | Плавный скролл |
| lucide-react | ^0.460.0 | Иконки |

## Компоненты

### Layout

| Компонент | Источник | Описание |
|-----------|----------|----------|
| Navigation | Custom | Фиксированная навигация с blur backdrop |
| Footer | Custom | 4-колоночный футер |
| SmoothScroll | Custom | Lenis-провайдер |

### Sections

| Компонент | Источник | Описание |
|-----------|----------|----------|
| HeroSection | Custom | Hero с WebGL фоном, badge, H1, CTA, stats |
| ServicesCarousel | Custom | Tilted carousel с 3 карточками услуг |
| FeaturesSection | Custom | Grid из 6 feature-карточек |
| PricingSection | Custom | 3 pricing карточки с highlight |
| PartnerSection | Custom | 2-колоночная секция партнерки |
| CTABannerSection | Custom | Центрированный CTA баннер |

### Переиспользуемые

| Компонент | Источник | Описание |
|-----------|----------|----------|
| StarfieldShader | Custom (WebGL) | Полноэкранный шейдер звездного неба |
| TiltedCarousel | Custom (GSAP) | Инфинити-карусель с tilt-эффектом |
| GradientText | Custom | Текст с градиентной заливкой |
| GlowCard | Custom | Карточка с hover glow-эффектом |
| SectionHeader | Custom | Заголовок секции с label + H2 |
| PillBadge | Custom | Badge в виде pill |

## Анимации

| Анимация | Библиотека | Реализация | Сложность |
|----------|-----------|------------|-----------|
| Starfield Shader | WebGL (raw) | Кастомный WebGL контекст, fullscreen quad, fragment shader с twinkling stars | High |
| Hero entrance sequence | GSAP Timeline | Staggered fade-in + slideUp для badge, H1, subtitle, CTA, stats | Medium |
| Section reveal | GSAP ScrollTrigger | Fade-in + translateY(40→0) для каждой секции при scroll | Low |
| Tilted Carousel | GSAP ScrollTrigger | Двойная timeline: yPercent stagger + x scrub, CSS 3D rotateY(-15deg) | High |
| Carousel hover flatten | GSAP | rotationY→0, img scale→1.05; reverse on leave | Medium |
| Card hover glow | CSS Transitions | border-color + box-shadow transition 0.3s | Low |
| Button hover | CSS Transitions | scale(1.02) + glow | Low |
| Nav link underline | CSS | width 0→100% from left, cyan color | Low |
| Custom cursor | Custom JS | requestAnimationFrame tracking, scale on interactive hover | Medium |

## State & Logic

- Lenis smooth scroll instance — глобальный контекст
- WebGL context lifecycle — создание/очистка при mount/unmount
- Carousel width calculation — динамический расчет scrollWidth для infinite feel
- Mouse tracking для starfield — нормализованные координаты [-1, 1]
- prefers-reduced-motion проверка — отключение всех анимаций

## Архитектура

```
src/
  sections/
    HeroSection.tsx
    ServicesCarousel.tsx
    FeaturesSection.tsx
    PricingSection.tsx
    PartnerSection.tsx
    CTABannerSection.tsx
  components/
    Navigation.tsx
    Footer.tsx
    StarfieldShader.tsx
    TiltedCarousel.tsx
    GradientText.tsx
    GlowCard.tsx
    SectionHeader.tsx
    PillBadge.tsx
    SmoothScroll.tsx
  hooks/
    useLenis.ts
    useReducedMotion.ts
  App.tsx
  main.tsx
  index.css
```

## Особенности реализации

1. **Starfield Shader** — используем raw WebGL (не R3F) для простого fullscreen fragment shader. Single fullscreen triangle, no geometry needed.
2. **Tilted Carousel** — GSAP ScrollTrigger с `scrub: 1.5`. Два параллельных tween: yPercent stagger для списка + x translation для wrap. Hover flatten через GSAP tween.
3. **Responsive** — мобильная карусель: убираем 3D tilt, делаем обычный horizontal scroll. Pricing cards — 1 колонка на мобильном.
4. **Performance** — `will-change: transform` на карусели, DPR для canvas, lazy load секций.
5. **Accessibility** — `prefers-reduced-motion` отключает все анимации.
