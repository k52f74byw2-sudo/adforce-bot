# Как загрузить бота на GitHub

## Шаг 1 — Скачай ZIP
Файл: `adforce-bot.zip` (в папке bot/)

## Шаг 2 — Создай репозиторий
1. Зайди на https://github.com/new
2. Repository name: `adforce-bot`
3. Нажми **Create repository**

## Шаг 3 — Загрузи файлы
1. На странице репозитория нажми **"uploading an existing file"**
2. Или перетащи файлы из ZIP прямо на страницу
3. Нажми **Commit changes**

## Шаг 4 — Ссылка готова!
Твоя ссылка будет: `https://github.com/ТВОЙ_НИК/adforce-bot`

## Шаг 5 — Подключи к Bothost / Render
Вставь эту ссылку при создании проекта на хостинге.

---

# Или ещё проще — через терминал:

```bash
# Распакуй ZIP
cd adforce-bot

# Инициализируй git
git init
git add .
git commit -m "AdForce bot"

# Подключи к GitHub (замени ТВОЙ_НИК)
git remote add origin https://github.com/ТВОЙ_НИК/adforce-bot.git
git push -u origin main
```

✅ Готово! Ссылка: `https://github.com/ТВОЙ_НИК/adforce-bot`
