# Бесплатный деплой бота — без подписок, без карт

---

## Вариант 1: PythonAnywhere (бесплатно) ⭐

**Плюсы:** Полностью бесплатно, просто, ничего не нужно устанавливать
**Минусы:** Нужно заходить раз в день и нажимать "Run" (или настроить cron)

### Шаг 1 — Регистрация
1. Зайди на https://www.pythonanywhere.com
2. Нажми **"Start running Python online in less than a minute"**
3. Заполни: username, email, password
4. Нажми **Register**

### Шаг 2 — Загрузка файлов
1. В панели нажми **"Files"** (вверху)
2. В поле путь введи: `bot.py`
3. Вставь содержимое файла `bot.py` (скопируй отсюда)
4. Нажми **Save**
5. Тоже самое для `requirements.txt`:
   - Путь: `requirements.txt`
   - Содержимое:
     ```
     python-telegram-bot==21.4
     aiohttp==3.9.5
     ```

### Шаг 3 — Установка библиотек
1. Нажми **"Consoles"** → **"Bash"**
2. Выполни:
   ```bash
   pip3 install --user python-telegram-bot==21.4 aiohttp==3.9.5
   ```

### Шаг 4 — Переменные окружения
В той же консоли Bash выполни:
```bash
echo 'export TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"' >> ~/.bashrc
echo 'export CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"' >> ~/.bashrc
echo 'export STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"' >> ~/.bashrc
echo 'export MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"' >> ~/.bashrc
source ~/.bashrc
```

### Шаг 5 — Запуск
В той же консоли:
```bash
cd ~
python3 bot.py
```

✅ Бот работает! Оставь вкладку открытой.

### Чтобы не перезапускать каждый день:
Настрой **Always-on task** (для этого нужен платный аккаунт, $5/мес) или просто заходи раз в день и нажимай **Run**.

---

## Вариант 2: Запуск на своём компьютере/телефоне (100% бесплатно)

### На компьютере (Windows/Mac/Linux):

1. Установи Python: https://python.org/downloads
2. Создай папку `adforce-bot`
3. Положи туда файлы `bot.py` и `requirements.txt`
4. Открой терминал (cmd/PowerShell/Terminal) в этой папке
5. Выполни:
```bash
pip install python-telegram-bot==21.4 aiohttp==3.9.5
set TELEGRAM_BOT_TOKEN=8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw
set CRYPTOBOT_TOKEN=598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA
set STREAM_API_KEY=roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY
set MINI_APP_URL=https://kcgxjw54o6ji2.kimi.page
python bot.py
```

✅ Бот работает пока компьютер включен!

### На телефоне Android (через Termux):

1. Установи **Termux** из F-Droid (НЕ из Google Play!)
2. Открой Termux и выполни:
```bash
pkg update
pkg install python git -y
pip install python-telegram-bot==21.4 aiohttp==3.9.5
```
3. Создай файл бота:
```bash
nano bot.py
# Вставь содержимое bot.py (Ctrl+V), сохрани (Ctrl+O, Enter, Ctrl+X)
```
4. Запусти:
```bash
export TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"
export CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"
export STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"
export MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"
python bot.py
```

✅ Бот работает пока Termux запущен!

---

## Вариант 3: Google Apps Script (бесплатно навсегда)

Если PythonAnywhere не подходит, можно переписать логику на Google Apps Script (JavaScript) и запускать через Google Sheets. Но это сложнее.

---

## Сравнение

| Вариант | Цена | Сложность | Надёжность |
|---------|------|-----------|------------|
| **PythonAnywhere** | $0 | ⭐ Легко | ⭐⭐ (sleep 24ч) |
| **Свой комп** | $0 | ⭐⭐ Средне | ⭐⭐⭐ |
| **Телефон (Termux)** | $0 | ⭐⭐ Средне | ⭐⭐ |

---

## Рекомендация

Начни с **PythonAnywhere** — заходи раз в день, нажимай Run. Это 30 секунд в день, зато полностью бесплатно.

Когда начнёшь зарабатывать — перейдёшь на платный хостинг ($5-7/мес).
