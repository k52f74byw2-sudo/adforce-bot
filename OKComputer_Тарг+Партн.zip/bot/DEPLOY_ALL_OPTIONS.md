# Все варианты деплоя бота (автоматические)

## ⭐ Вариант 1: Render.com — САМЫЙ ПРОСТОЙ

**Плюсы:** Бесплатно, не нужно устанавливать ничего, веб-интерфейс

1. Зарегистрируйся на https://render.com (через GitHub)
2. Нажми **"New +"** → **"Background Worker"**
3. Подключи свой GitHub репозиторий
   - Или загрузи файлы через **"Upload"**
4. Укажи:
   - **Name:** `adforce-bot`
   - **Runtime:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`
5. В разделе **Environment** добавь переменные:
   ```
   TELEGRAM_BOT_TOKEN=8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw
   CRYPTOBOT_TOKEN=598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA
   STREAM_API_KEY=roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY
   MINI_APP_URL=https://kcgxjw54o6ji2.kimi.page
   ```
6. Нажми **Create Background Worker**

✅ Готово! Бот работает 24/7 автоматически.

---

## Вариант 2: Heroku (через наш скрипт)

**Плюсы:** Надёжно, много документации

```bash
# Установи Heroku CLI, затем:
bash deploy.sh
```

Скрипт сам всё создаст и настроит!

---

## Вариант 3: Fly.io

**Плюсы:** Бесплатный tier, быстрый

```bash
# Установи flyctl: https://fly.io/docs/hands-on/install-flyctl/
fly auth login
fly launch --config fly.toml
fly deploy
```

✅ Бот запущен!

---

## Вариант 4: PythonAnywhere (бесплатно)

**Плюсы:** Полностью бесплатно, простой интерфейс
**Минусы:** Спит каждые 24 часа (нужно зайти и нажать Run)

1. Зарегистрируйся на https://pythonanywhere.com
2. Загрузи файлы `bot.py` и `requirements.txt`
3. Открой **Consoles** → **Bash**
4. Установи зависимости:
   ```bash
   pip3 install --user python-telegram-bot==21.4 aiohttp==3.9.5
   ```
5. Установи переменные:
   ```bash
   echo 'export TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"' >> ~/.bashrc
   echo 'export CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"' >> ~/.bashrc
   echo 'export STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"' >> ~/.bashrc
   echo 'export MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"' >> ~/.bashrc
   source ~/.bashrc
   ```
6. Запусти бота:
   ```bash
   python3 bot.py
   ```

---

## Вариант 5: VPS/Сервер (самый надёжный)

Если у тебя есть любой сервер (VPS):

```bash
# Скопируй файлы на сервер
scp bot.py requirements.txt root@твой-сервер:/root/adforce/

# Подключись
ssh root@твой-сервер

# Установи
cd /root/adforce
pip install -r requirements.txt

# Запусти через systemd (автозапуск при перезагрузке)
cat > /etc/systemd/system/adforce-bot.service << 'EOF'
[Unit]
Description=AdForce Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=/root/adforce
ExecStart=/usr/bin/python3 /root/adforce/bot.py
Restart=always
RestartSec=10
Environment="TELEGRAM_BOT_TOKEN=8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"
Environment="CRYPTOBOT_TOKEN=598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"
Environment="STREAM_API_KEY=roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"
Environment="MINI_APP_URL=https://kcgxjw54o6ji2.kimi.page"

[Install]
WantedBy=multi-user.target
EOF

systemctl enable adforce-bot
systemctl start adforce-bot

# Проверь статус
systemctl status adforce-bot
```

✅ Бот будет работать вечно, автоперезапуск при падении!

---

## Сравнение вариантов

| Вариант | Цена | Сложность | Надёжность |
|---------|------|-----------|------------|
| **Render.com** | Бесплатно | ⭐ Легко | ⭐⭐⭐ |
| **Heroku** | $7/мес | ⭐⭐ Средне | ⭐⭐⭐⭐ |
| **Fly.io** | Бесплатно | ⭐⭐ Средне | ⭐⭐⭐ |
| **PythonAnywhere** | Бесплатно | ⭐ Легко | ⭐⭐ (sleep) |
| **VPS** | $3-5/мес | ⭐⭐⭐ Сложно | ⭐⭐⭐⭐⭐ |

---

## Рекомендация

Начни с **Render.com** — самый простой, бесплатный, работает 24/7.

Когда проект вырастет — переходи на **VPS** (Hetzner от $3/мес).
