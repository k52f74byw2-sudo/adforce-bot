#!/bin/bash
# Автоматический деплой AdForce бота на Heroku

set -e

echo "═══════════════════════════════════════════"
echo "  AdForce Bot — Автодеплой"
echo "═══════════════════════════════════════════"
echo ""

APP_NAME="${1:-adforce-russia-bot}"

# Проверка heroku CLI
if ! command -v heroku &> /dev/null; then
    echo "❌ Установите Heroku CLI:"
    echo "   https://devcenter.heroku.com/articles/heroku-cli"
    exit 1
fi

echo "🔐 Проверка логина..."
heroku auth:whoami &>/dev/null || heroku login

echo ""
echo "📦 Создание приложения $APP_NAME..."
heroku create "$APP_NAME" 2>/dev/null || echo "Приложение уже существует"

echo ""
echo "🔑 Установка переменных окружения..."
heroku config:set TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw" --app "$APP_NAME"
heroku config:set CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA" --app "$APP_NAME"
heroku config:set STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY" --app "$APP_NAME"
heroku config:set MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page" --app "$APP_NAME"

echo ""
echo "🚀 Деплой..."
git init 2>/dev/null || true
git add -A
git commit -m "Deploy $(date)" 2>/dev/null || true
heroku git:remote -a "$APP_NAME" 2>/dev/null || true
git push heroku main 2>/dev/null || git push heroku master 2>/dev/null || echo "Push требует настройки git"

echo ""
echo "⚡ Запуск worker..."
heroku ps:scale worker=1 --app "$APP_NAME"

echo ""
echo "═══════════════════════════════════════════"
echo "  ✅ Бот задеплоен!"
echo "═══════════════════════════════════════════"
echo ""
echo "Логи: heroku logs --tail --app $APP_NAME"
echo "Стоп:  heroku ps:scale worker=0 --app $APP_NAME"
echo "Старт: heroku ps:scale worker=1 --app $APP_NAME"
echo ""
