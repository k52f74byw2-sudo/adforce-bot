# Деплой на Render.com — БЕСПЛАТНО

## Что нужно
- Аккаунт GitHub (бесплатно)
- 5 минут времени

## Шаг 1 — Залить код на GitHub

1. Зайди на https://github.com/new
2. Название репозитория: `adforce-bot`
3. Нажми **Create repository**
4. Загрузи файлы:
   - `bot.py`
   - `requirements.txt`
   - `Procfile`
5. Нажми **Commit**

## Шаг 2 — Подключить Render

1. Зайди на https://render.com
2. Нажми **Sign Up** → залогинься через GitHub
3. Нажми **New +** → **Background Worker**

## Шаг 3 — Настроить

Заполни поля:

| Поле | Значение |
|------|----------|
| Name | `adforce-bot` |
| Runtime | `Python 3` |
| Build Command | `pip install -r requirements.txt` |
| Start Command | `python bot.py` |

## Шаг 4 — Добавить переменные окружения

Нажми **Advanced** → **Add Environment Variable**, добавь 4 штуки:

```
TELEGRAM_BOT_TOKEN=8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw
CRYPTOBOT_TOKEN=598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA
STREAM_API_KEY=roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY
MINI_APP_URL=https://kcgxjw54o6ji2.kimi.page
```

## Шаг 5 — Запустить

Нажми **Create Background Worker**

✅ Готово! Бот работает бесплатно 24/7!

## Проверка

Напиши своему боту `@AdForceRussiaBot`:
```
/start
```

Если ответил — всё работает!

## Пополнить баланс

1. Открой Mini App → Профиль → Админ панель
2. Нажми **Пополнить баланс**
3. На сайте stream-promotion.ru пополни через:
   - **Карта** (Россия)
   - **FreeKassa** (крипта, электронные кошельки)
   - **Crypto** (USDT, BTC)

Минимум пополнения: обычно 100-500 руб.
