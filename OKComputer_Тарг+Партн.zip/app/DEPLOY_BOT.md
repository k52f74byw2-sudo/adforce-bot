# Деплой бота AdForce с CryptoBot

## Что нужно

| Переменная | Значение | Есть? |
|-----------|----------|-------|
| `TELEGRAM_BOT_TOKEN` | `8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw` | ✅ |
| `CRYPTOBOT_TOKEN` | `598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA` | ✅ |
| `STREAM_API_KEY` | `roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY` | ✅ |
| `MINI_APP_URL` | `https://kcgxjw54o6ji2.kimi.page` | ✅ |

## Вариант 1: Heroku (рекомендуется)

### Шаг 1 — Установи Heroku CLI
https://devcenter.heroku.com/articles/heroku-cli

### Шаг 2 — Создай приложение
```bash
heroku login
heroku create adforce-russia-bot
```

### Шаг 3 — Установи переменные окружения
```bash
heroku config:set TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw" --app adforce-russia-bot
heroku config:set CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA" --app adforce-russia-bot
heroku config:set STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY" --app adforce-russia-bot
heroku config:set MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page" --app adforce-russia-bot
```

### Шаг 4 — Деплой
```bash
cd /путь/к/папке/с/bot.py
git init
git add bot.py Procfile requirements.txt runtime.txt
git commit -m "Initial deploy"
git push heroku main
```

### Шаг 5 — Запусти worker
```bash
heroku ps:scale worker=1 --app adforce-russia-bot
```

### Шаг 6 — Проверь логи
```bash
heroku logs --tail --app adforce-russia-bot
```

## Вариант 2: PythonAnywhere (бесплатно)

1. Зарегистрируйся на https://pythonanywhere.com
2. Загрузи файлы `bot.py`, `requirements.txt`
3. Открой консоль Bash
4. Установи зависимости: `pip install python-telegram-bot aiohttp`
5. Установи переменные:
```bash
export TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"
export CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"
export STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"
export MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"
```
6. Запусти: `python bot.py`
7. Настрой "Always-on task" для 24/7 работы

## Вариант 3: Локально (для теста)

```bash
cd /путь/к/папке
export TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"
export CRYPTOBOT_TOKEN="598029:AADkHW9prApv1gJyTE11LvnFsVvMsHKsihA"
export STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"
export MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"

pip install python-telegram-bot==21.4 aiohttp==3.9.5
python bot.py
```

## Как работает оплата с CryptoBot

```
Пользователь → Mini App → Выбирает "USDT (Crypto)"
    → tg.sendData() → Бот
    → Бот создаёт инвойс через CryptoBot API
    → Пользователь получает кнопку "Оплатить USDT"
    → Переходит в CryptoBot → Оплачивает
    → Бот получает webhook → Автозаказ в stream-promotion.ru
```

## Управление ботом

```bash
# Посмотреть логи
heroku logs --tail --app adforce-russia-bot

# Перезапустить
heroku ps:restart worker --app adforce-russia-bot

# Остановить
heroku ps:scale worker=0 --app adforce-russia-bot

# Запустить
heroku ps:scale worker=1 --app adforce-russia-bot
```
