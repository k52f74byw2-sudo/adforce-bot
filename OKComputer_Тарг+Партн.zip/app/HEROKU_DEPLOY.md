# Heroku Deployment Guide — AdForce Russia Bot

## Что было создано

Для полной автоматизации создано **4 файла**:

| Файл | Назначение |
|------|------------|
| `bot.py` | Полноценный Telegram-бот с обработкой платежей |
| `Procfile` | Инструкция Heroku — как запускать бота |
| `requirements.txt` | Python-зависимости |
| `runtime.txt` | Версия Python (3.11.6) |
| `deploy_heroku.sh` | Скрипт автоматического деплоя |

## Что умеет бот

1. **Команды:**
   - `/start` — Приветствие + кнопка открытия Mini App
   - `/balance` — Проверка баланса API
   - `/status <id>` — Проверка статуса заказа
   - `/help` — Помощь

2. **Обработка заказов из Mini App:**
   - Получает данные через `web_app_data`
   - Показывает детали заказа с кнопками оплаты
   - Поддерживает **Telegram Stars** (нативная оплата)
   - Поддерживает **USDT** (через CryptoBot или вручную)

3. **После оплаты:**
   - Автоматически отправляет заказы в stream-promotion.ru API
   - Сообщает пользователю результат (ID заказов)
   - Показывает статус каждой услуги

## Способы деплоя на Heroku

### Способ 1: Через скрипт (автоматический)

```bash
# Установите Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli
# Залогиньтесь:
heroku login

# Запустите скрипт:
bash deploy_heroku.sh adforce-russia-bot
```

### Способ 2: Вручную (пошагово)

**Шаг 1 — Установка Heroku CLI:**
```bash
# macOS
brew install heroku

# Ubuntu/Debian
sudo snap install --classic heroku

# Windows (через installer)
# https://devcenter.heroku.com/articles/heroku-cli
```

**Шаг 2 — Логин:**
```bash
heroku login
```

**Шаг 3 — Создание приложения:**
```bash
cd /mnt/agents/output/app
heroku create adforce-russia-bot
```

**Шаг 4 — Переменные окружения:**
```bash
heroku config:set TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw"
heroku config:set STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY"
heroku config:set MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page"
```

**Шаг 5 — Деплой:**
```bash
git add -A
git commit -m "Initial bot deploy"
git push heroku main
```

**Шаг 6 — Запуск worker:**
```bash
heroku ps:scale worker=1
```

**Шаг 7 — Проверка логов:**
```bash
heroku logs --tail
```

## Управление ботом

| Команда | Действие |
|---------|----------|
| `heroku logs --tail` | Смотреть логи в реальном времени |
| `heroku ps:restart worker` | Перезапустить бота |
| `heroku ps:scale worker=0` | Остановить бота |
| `heroku ps:scale worker=1` | Запустить бота |
| `heroku config` | Показать переменные |

## Цена Heroku

- **Бесплатный план (Eco):** ~$5/месяц (доступно 1000 dyno-часов)
- **Hobby:** $7/месяц (работает 24/7)

## Альтернативы Heroku (бесплатные)

Если Heroku платный, можно использовать:

### 1. PythonAnywhere (бесплатно)
- Регистрация: pythonanywhere.com
- Загрузите bot.py, установите зависимости
- Запустите как "Always-on task"

### 2. Railway.app
- Бесплатно до $5/мес лимита
- Просто загрузите код — всё настроится автоматически

### 3. Fly.io
- Есть бесплатный tier
- `fly launch` — и приложение в облаке

### 4. Oracle Cloud (Always Free)
- Полностью бесплатно навсегда
- Нужна кредитная карта для верификации

## Как это работает вместе

```
Пользователь → Открывает @AdForceRussiaBot
      ↓
Нажимает "🚀 Открыть AdForce"
      ↓
Mini App загружается (kimi.page)
      ↓
Выбирает услуги → Добавляет в корзину
      ↓
Нажимает "Оплатить" → tg.sendData()
      ↓
Данные приходят в bot.py (Heroku)
      ↓
Бот показывает счет (Stars или USDT)
      ↓
Пользователь оплачивает
      ↓
Бот автоматически создает заказ в stream-promotion.ru
      ↓
Услуга начинает выполняться!
```

## Поддержка

По вопросам обращайтесь в Telegram: @adforce_support
