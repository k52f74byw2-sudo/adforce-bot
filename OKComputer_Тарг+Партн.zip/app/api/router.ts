import { yookassaRouter } from "./yookassa-router";
import { streamRouter } from "./stream-router";
import { paymentRouter } from "./payment-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  yookassa: yookassaRouter,
  stream: streamRouter,
  payment: paymentRouter,
});

export type AppRouter = typeof appRouter;
