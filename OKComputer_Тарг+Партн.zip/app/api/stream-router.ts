import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";

const API_KEY = 'roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY';
const API_BASE = 'https://stream-promotion.ru/api/v2';

interface ApiService {
  service: number;
  name: string;
  category: string;
  rate: string;
  min: string;
  max: string;
  type: string;
  desc: string;
  dripfeed: boolean;
  refill: boolean;
  cancel: boolean;
}

async function apiRequest(params: Record<string, string>): Promise<any> {
  const url = new URL(API_BASE);
  url.searchParams.set('key', API_KEY);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, value);
  }
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.json();
}

export const streamRouter = createRouter({
  services: publicQuery.query(async () => {
    const data = await apiRequest({ action: 'services' });
    if (!Array.isArray(data)) throw new Error('Invalid API response');

    return data.map((s: any): ApiService => ({
      service: Number(s.service),
      name: String(s.name || ''),
      category: String(s.category || 'Другие'),
      rate: String(s.rate || '0'),
      min: String(s.min || '0'),
      max: String(s.max || '0'),
      type: String(s.type || 'default'),
      desc: String(s.desc || ''),
      dripfeed: Boolean(s.dripfeed),
      refill: Boolean(s.refill),
      cancel: Boolean(s.cancel),
    }));
  }),

  placeOrder: publicQuery
    .input(z.object({
      service: z.number().int().positive(),
      link: z.string().min(1).max(2000),
      quantity: z.number().int().min(1),
    }))
    .mutation(async ({ input }) => {
      const data = await apiRequest({
        action: 'add',
        service: String(input.service),
        link: input.link,
        quantity: String(input.quantity),
      });
      if (data.error) throw new Error(data.error);
      return { order: data.order };
    }),

  orderStatus: publicQuery
    .input(z.number().int().positive())
    .query(async ({ input }) => {
      const data = await apiRequest({ action: 'status', order: String(input) });
      if (data.error) throw new Error(data.error);
      return {
        charge: String(data.charge || '0'),
        start_count: String(data.start_count || '0'),
        status: String(data.status || 'unknown'),
        remains: String(data.remains || '0'),
        currency: String(data.currency || 'RUB'),
      };
    }),

  balance: publicQuery.query(async () => {
    const data = await apiRequest({ action: 'balance' });
    if (data.error) throw new Error(data.error);
    return { balance: String(data.balance || '0'), currency: String(data.currency || 'RUB') };
  }),

  placeBulkOrders: publicQuery
    .input(z.array(z.object({
      service: z.number().int().positive(),
      link: z.string().min(1).max(2000),
      quantity: z.number().int().min(1),
    })))
    .mutation(async ({ input }) => {
      const results: { service: number; order: number | null; error?: string }[] = [];
      for (const orderReq of input) {
        try {
          const data = await apiRequest({
            action: 'add',
            service: String(orderReq.service),
            link: orderReq.link,
            quantity: String(orderReq.quantity),
          });
          if (data.error) {
            results.push({ service: orderReq.service, order: null, error: data.error });
          } else {
            results.push({ service: orderReq.service, order: data.order });
          }
        } catch (e: any) {
          results.push({ service: orderReq.service, order: null, error: e.message });
        }
      }
      return results;
    }),
});
