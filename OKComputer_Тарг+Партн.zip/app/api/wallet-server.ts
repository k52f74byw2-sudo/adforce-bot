// ─── Wallet Pay Backend Server ────────────────────────────────────
// Hono server for creating invoices & handling webhooks

import { Hono } from "hono";
import { cors } from "hono/cors";
import { WalletPayClient } from "./wallet";

const app = new Hono();
const walletToken = process.env.WALLET_PAY_TOKEN || "";
const walletClient = walletToken ? new WalletPayClient(walletToken) : null;

// Pending orders storage (use DB in production)
const pendingOrders: Record<string, {
  userId: number;
  items: any[];
  link: string;
  status: string;
  amount: string;
  currency: string;
}> = {};

app.use("*", cors({
  origin: ["https://kcgxjw54o6ji2.kimi.page", "*"],
  allowMethods: ["POST", "GET", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
}));

// Health check
app.get("/api/wallet/health", (c) => c.json({ ok: true, wallet: !!walletClient }));

// Create invoice
app.post("/api/wallet/create-invoice", async (c) => {
  try {
    if (!walletClient) {
      return c.json({ error: "Wallet Pay not configured" }, 500);
    }

    const body = await c.req.json();
    const { amount, currency, description, externalId, returnUrl } = body;

    if (!amount || !currency || !externalId) {
      return c.json({ error: "Missing amount, currency, or externalId" }, 400);
    }

    // Store order info
    pendingOrders[externalId] = {
      userId: body.userId || 0,
      items: body.items || [],
      link: body.link || "",
      status: "pending",
      amount,
      currency,
    };

    const result = await walletClient.createInvoice({
      amount: {
        currencyCode: currency,
        amount: String(amount),
      },
      externalId,
      timeoutSeconds: 3600,
      description: description || "AdForce Agency",
      returnUrl: returnUrl || "https://t.me/AdForceRussiaBot",
      customData: JSON.stringify({ items: body.items, link: body.link }),
    });

    return c.json({
      success: true,
      payLink: result.data?.payLink || result.data?.directPayLink,
      orderId: result.data?.id,
      externalId,
    });
  } catch (e: any) {
    console.error("Wallet invoice error:", e);
    return c.json({ error: e.message || "Unknown error" }, 500);
  }
});

// Webhook — called by Wallet Pay after payment
app.post("/api/wallet/webhook", async (c) => {
  try {
    const body = await c.req.json();
    console.log("Wallet webhook:", JSON.stringify(body, null, 2));

    const { payload } = body;
    if (!payload) return c.json({ ok: true });

    const orderId = payload.externalId;
    const order = pendingOrders[orderId];

    if (!order) {
      console.log(`Order ${orderId} not found`);
      return c.json({ ok: true });
    }

    if (payload.status === "PAID") {
      order.status = "paid";
      console.log(`Order ${orderId} PAID! Amount: ${payload.paidAmount?.amount} ${payload.paidAmount?.currencyCode}`);

      // Submit to stream-promotion.ru API
      await submitToStreamApi(order);

      // Notify user via bot
      await notifyUser(order.userId, `✅ Оплата получена!\nЗаказ ${orderId} выполняется...`);
    }

    return c.json({ ok: true });
  } catch (e: any) {
    console.error("Webhook error:", e);
    return c.json({ ok: true }); // Always return 200 to Wallet Pay
  }
});

// Check invoice status
app.get("/api/wallet/status", async (c) => {
  const orderId = c.req.query("orderId");
  if (!orderId || !walletClient) {
    return c.json({ error: "Missing orderId" }, 400);
  }

  try {
    const result = await walletClient.getInvoiceStatus(orderId);
    return c.json(result);
  } catch (e: any) {
    return c.json({ error: e.message }, 500);
  }
});

// Submit order to stream-promotion.ru API
async function submitToStreamApi(order: any) {
  const API_KEY = process.env.STREAM_API_KEY || "roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY";
  const API_BASE = "https://stream-promotion.ru/api/v2";

  for (const item of order.items || []) {
    try {
      const res = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          key: API_KEY,
          action: "add",
          service: String(item.service),
          quantity: String(item.qty),
          link: order.link || "",
        }),
      });
      const data = await res.json();
      console.log(`API order ${item.service}:`, data);
    } catch (e) {
      console.error(`API error for ${item.service}:`, e);
    }
  }
}

async function notifyUser(userId: number, message: string) {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw";
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: userId,
        text: message,
        parse_mode: "HTML",
      }),
    });
  } catch (e) {
    console.error("Notify error:", e);
  }
}

export default app;
