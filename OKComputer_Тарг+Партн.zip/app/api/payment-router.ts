import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";

const BOT_TOKEN = '8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw';
const TELEGRAM_API = 'https://api.telegram.org/bot' + BOT_TOKEN;
const CRYPTOBOT_API = 'https://pay.crypt.bot/api';
const CRYPTOBOT_TOKEN = ''; // Set your CryptoBot token here or via env

export const paymentRouter = createRouter({
  createStarsInvoice: publicQuery
    .input(
      z.object({
        title: z.string().min(1).max(32),
        description: z.string().min(1).max(255),
        amount: z.number().int().min(1),
        payload: z.string().max(128),
      })
    )
    .mutation(async ({ input }) => {
      const resp = await fetch(`${TELEGRAM_API}/createInvoiceLink`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: input.title,
          description: input.description,
          payload: input.payload,
          provider_token: '',
          currency: 'XTR',
          prices: [{ label: 'Услуга', amount: input.amount }],
        }),
      });

      const data: any = await resp.json();

      if (!data.ok) {
        throw new Error(data.description || 'Failed to create invoice');
      }

      return { invoiceUrl: data.result as string };
    }),

  createCryptoInvoice: publicQuery
    .input(
      z.object({
        amount: z.number().positive(),
        description: z.string().optional(),
        payload: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      if (!CRYPTOBOT_TOKEN) {
        throw new Error('CryptoBot не настроен. Добавьте CRYPTOBOT_TOKEN.');
      }

      const resp = await fetch(`${CRYPTOBOT_API}/createInvoice`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Crypto-Pay-API-Token': CRYPTOBOT_TOKEN,
        },
        body: JSON.stringify({
          asset: 'USDT',
          amount: input.amount,
          description: input.description || 'StreamBoost order',
          payload: input.payload || '',
          paid_btn_name: 'openBot',
          paid_btn_url: 'https://t.me/streamboost_bot',
        }),
      });

      const data: any = await resp.json();

      if (!data.ok) {
        throw new Error(data.error?.message || 'CryptoBot error');
      }

      return {
        invoiceId: data.result.invoice_id,
        payUrl: data.result.pay_url,
        miniAppPayUrl: data.result.mini_app_invoice_url,
      };
    }),
});
