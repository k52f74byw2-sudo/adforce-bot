// ─── Telegram Wallet Pay API Client ───────────────────────────────
// Docs: https://docs.wallet.tg/pay/

const WALLET_API = "https://pay.wallet.tg/wpay/store-api/v1";

export interface WalletInvoice {
  amount: {
    currencyCode: string; // "USDT" | "TON" | "BTC"
    amount: string;
  };
  externalId: string;
  timeoutSeconds: number;
  description: string;
  returnUrl?: string;
  failReturnUrl?: string;
  customData?: string;
}

export interface WalletInvoiceResponse {
  status: string;
  message?: string;
  data?: {
    id: string;
    status: string;
    payLink: string;
    directPayLink: string;
    amount: { currencyCode: string; amount: string };
    externalId: string;
  };
}

export class WalletPayClient {
  private token: string;

  constructor(token: string) {
    this.token = token;
  }

  private async request<T>(method: string, path: string, body?: unknown): Promise<T> {
    const url = `${WALLET_API}${path}`;
    const res = await fetch(url, {
      method,
      headers: {
        "Wpay-Store-Api-Key": this.token,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Wallet API ${res.status}: ${text}`);
    }

    return res.json() as Promise<T>;
  }

  /** Create a payment invoice */
  async createInvoice(invoice: WalletInvoice): Promise<WalletInvoiceResponse> {
    return this.request<WalletInvoiceResponse>("POST", "/order", invoice);
  }

  /** Get invoice status */
  async getInvoiceStatus(orderId: string): Promise<WalletInvoiceResponse> {
    return this.request<WalletInvoiceResponse>("GET", `/order?id=${orderId}`);
  }

  /** Get available payment methods */
 async getAvailableMethods(): Promise<{ currencies: string[] }> {
    return this.request<{ currencies: string[] }>("GET", "/get-available-pay-methods");
  }
}
