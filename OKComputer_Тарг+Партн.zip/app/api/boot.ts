import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";

const app = new Hono();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));

// Health check
app.get("/api/health", (c) => c.json({ ok: true, ts: Date.now() }));

// tRPC handler
app.all("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext: () => ({ req: c.req.raw, resHeaders: new Headers() }),
  });
});

// YooKassa webhook
app.post("/api/webhook/yookassa", async (c) => {
  const body = await c.req.json();
  const caller = appRouter.createCaller({ req: c.req.raw, resHeaders: new Headers() });
  try {
    await caller.yookassa.webhook(body);
    return c.json({ received: true });
  } catch {
    return c.json({ received: true });
  }
});

// Serve static files (frontend build)
app.get("*", async (c) => {
  try {
    const url = new URL(c.req.url);
    const path = url.pathname === "/" ? "/index.html" : url.pathname;
    const file = await import("node:fs").then(fs => fs.readFileSync(`./dist/public${path}`));
    const contentType = path.endsWith(".js") ? "application/javascript"
      : path.endsWith(".css") ? "text/css"
      : path.endsWith(".html") ? "text/html"
      : "application/octet-stream";
    return new Response(file, { headers: { "Content-Type": contentType } });
  } catch {
    const index = await import("node:fs").then(fs => fs.readFileSync("./dist/public/index.html"));
    return new Response(index, { headers: { "Content-Type": "text/html" } });
  }
});

export default app;
