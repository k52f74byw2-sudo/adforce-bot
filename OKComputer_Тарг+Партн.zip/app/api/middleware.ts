import { initTRPC } from "@trpc/server";

interface BasicContext {
  req: Request;
  resHeaders: Headers;
}

const t = initTRPC.context<BasicContext>().create();

export const createRouter = t.router;
export const publicQuery = t.procedure;
