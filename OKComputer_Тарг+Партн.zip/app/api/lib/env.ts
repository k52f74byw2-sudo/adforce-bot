declare var process: any;

// Simple env loader - no dotenv dependency
export const env = {
  appId: "",
  appSecret: "",
  isProduction: false,
  databaseUrl: "",
  appUrl: "https://streamboost.ru",
  yookassaShopId: "",
  yookassaSecretKey: "",
};

// Try to load from process.env if available
try {
  if (typeof process !== "undefined" && process.env) {
    env.appId = process.env.APP_ID || "";
    env.appSecret = process.env.APP_SECRET || "";
    env.isProduction = process.env.NODE_ENV === "production";
    env.databaseUrl = process.env.DATABASE_URL || "";
    env.appUrl = process.env.APP_URL || "https://streamboost.ru";
    env.yookassaShopId = process.env.YOOKASSA_SHOP_ID || "";
    env.yookassaSecretKey = process.env.YOOKASSA_SECRET_KEY || "";
  }
} catch { /* ignore */ }
