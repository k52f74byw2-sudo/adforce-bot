import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { env } from "./lib/env";

const SHOP_ID = env.yookassaShopId || "";
const SECRET_KEY = env.yookassaSecretKey || "";
const YOOKASSA_API = "https://api.yookassa.ru/v3";

interface YooKassaPayment {
  id: string;
  status: "pending" | "waiting_for_capture" | "succeeded" | "canceled";
  amount: { value: string; currency: string };
  confirmation?: { type: string; confirmation_url?: string };
  created_at: string;
  description?: string;
  metadata?: Record<string, string>;
}

export const yookassaRouter = createRouter({
  config: publicQuery.query(() => ({
    configured: !!(SHOP_ID && SECRET_KEY),
  })),

  createCampaignPayment: publicQuery
    .input(
      z.object({
        amount: z.number().int().min(100).max(500000),
        description: z.string().min(1).max(255),
        campaignData: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      if (!SHOP_ID || !SECRET_KEY) throw new Error("YooKassa not configured");

      const idempotenceKey = `sb-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const resp = await fetch(`${YOOKASSA_API}/payments`, {
        method: "POST",
        headers: {
          Authorization: `Basic ${btoa(`${SHOP_ID}:${SECRET_KEY}`)}`,
          "Content-Type": "application/json",
          "Idempotence-Key": idempotenceKey,
        },
        body: JSON.stringify({
          amount: { value: (input.amount / 100).toFixed(2), currency: "RUB" },
          capture: true,
          confirmation: {
            type: "redirect",
            return_url: `${env.appUrl || "https://streamboost.ru"}/payment/success`,
          },
          description: input.description,
          metadata: {
            type: "campaign",
            campaignData: input.campaignData || "",
          },
        }),
      });

      const data = (await resp.json()) as YooKassaPayment;

      if (!resp.ok) {
        throw new Error((data as any).description || "Payment creation failed");
      }

      return {
        yookassaPaymentId: data.id,
        confirmationUrl: data.confirmation?.confirmation_url,
        status: data.status,
      };
    }),

  webhook: publicQuery
    .input(
      z.object({
        type: z.string(),
        event: z.string(),
        object: z.object({
          id: z.string(),
          status: z.string(),
          amount: z.object({ value: z.string(), currency: z.string }),
          description: z.string().optional(),
          metadata: z.record(z.string(), z.string()).optional(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const { object } = input;

      if (object.status === "succeeded") {
        const campaignData = object.metadata?.campaignData;
        if (campaignData) {
          try {
            const orders = JSON.parse(campaignData);
            for (const order of orders.orders || []) {
              await fetch(`https://stream-promotion.ru/api/v2?key=roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY&action=add&service=${order.service}&link=${encodeURIComponent(order.link)}&quantity=${order.quantity}`);
            }
          } catch (e) {
            console.error("Auto-order failed:", e);
          }
        }
      }

      return { received: true };
    }),
});
