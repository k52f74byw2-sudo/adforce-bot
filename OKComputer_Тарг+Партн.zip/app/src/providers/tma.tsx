import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import WebApp from '@twa-dev/sdk';

interface TMAContextValue {
  ready: boolean;
  isTelegram: boolean;
  user: { id: number; firstName: string; username?: string; photoUrl?: string } | null;
  showAlert: (message: string) => void;
  showConfirm: (message: string) => Promise<boolean>;
  haptic: (type: 'impact' | 'notification' | 'selection', style?: string) => void;
  close: () => void;
  expand: () => void;
}

const TMAContext = createContext<TMAContextValue>({
  ready: false,
  isTelegram: false,
  user: null,
  showAlert: (m: string) => alert(m),
  showConfirm: (m: string) => Promise.resolve(confirm(m)),
  haptic: () => {},
  close: () => {},
  expand: () => {},
});

export function TMAProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);

  // Extract user data safely
  const user = (() => {
    try {
      const u = WebApp.initDataUnsafe?.user;
      if (!u) return null;
      return { id: u.id, firstName: u.first_name, username: u.username, photoUrl: u.photo_url };
    } catch { return null; }
  })();

  const isTelegram = !!user;

  useEffect(() => {
    try {
      WebApp.ready();
      WebApp.expand();
      try { (WebApp as any).setHeaderColor?.('#0a0a0f'); } catch { /* */ }
      try { (WebApp as any).setBackgroundColor?.('#0a0a0f'); } catch { /* */ }
      try { (WebApp as any).disableVerticalSwipes?.(); } catch { /* */ }
    } catch { /* Not in Telegram */ }
    setReady(true);
  }, []);

  const showAlert = useCallback((message: string) => {
    try { WebApp.showAlert(message); } catch { alert(message); }
  }, []);

  const showConfirm = useCallback((message: string): Promise<boolean> => {
    try {
      return new Promise((resolve) => {
        WebApp.showConfirm(message, (confirmed: boolean) => resolve(confirmed));
      });
    } catch { return Promise.resolve(confirm(message)); }
  }, []);

  const haptic = useCallback((type: 'impact' | 'notification' | 'selection', style?: string) => {
    try {
      if (type === 'impact') WebApp.HapticFeedback.impactOccurred(style as any || 'medium');
      else if (type === 'notification') WebApp.HapticFeedback.notificationOccurred(style as any || 'success');
      else WebApp.HapticFeedback.selectionChanged();
    } catch { /* haptic not supported */ }
  }, []);

  return (
    <TMAContext.Provider value={{
      ready, isTelegram, user,
      showAlert, showConfirm, haptic,
      close: () => { try { WebApp.close(); } catch { /* */ } },
      expand: () => { try { WebApp.expand(); } catch { /* */ } },
    }}>
      {children}
    </TMAContext.Provider>
  );
}

export function useTMA() {
  return useContext(TMAContext);
}
