import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

interface CartItem {
  service: number;
  qty: number;
  name: string;
  rate: string;
}

interface CartContextValue {
  cart: Record<number, number>;
  cartItems: CartItem[];
  cartTotal: number;
  addToCart: (serviceId: number, minQty: number, name: string, rate: string) => void;
  updateQty: (serviceId: number, delta: number) => void;
  setQty: (serviceId: number, qty: number) => void;
  removeFromCart: (serviceId: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

// Safe localStorage wrapper
function safeGet(key: string): Record<string, any> {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : {}; } catch { return {}; }
}
function safeSet(key: string, val: any) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* Telegram WebView may block */ }
}
function safeRemove(key: string) {
  try { localStorage.removeItem(key); } catch { /* ignore */ }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<Record<number, number>>(() => safeGet('sb_cart'));
  const [itemData, setItemData] = useState<Record<number, { name: string; rate: string }>>(() => safeGet('sb_items'));

  const addToCart = useCallback((serviceId: number, minQty: number, name: string, rate: string) => {
    setCart(prev => {
      const next = { ...prev, [serviceId]: (prev[serviceId] || 0) + minQty };
      safeSet('sb_cart', next);
      return next;
    });
    setItemData(prev => {
      const next = { ...prev, [serviceId]: { name, rate } };
      safeSet('sb_items', next);
      return next;
    });
  }, []);

  const updateQty = useCallback((serviceId: number, delta: number) => {
    setCart(prev => {
      const current = prev[serviceId] || 0;
      const newQty = current + delta;
      let next: Record<number, number>;
      if (newQty <= 0) {
        const { [serviceId]: _, ...rest } = prev;
        next = rest;
      } else {
        next = { ...prev, [serviceId]: newQty };
      }
      safeSet('sb_cart', next);
      return next;
    });
  }, []);

  const setQty = useCallback((serviceId: number, qty: number) => {
    if (qty <= 0) {
      removeFromCart(serviceId);
      return;
    }
    setCart(prev => {
      const next = { ...prev, [serviceId]: qty };
      safeSet('sb_cart', next);
      return next;
    });
  }, []);

  const removeFromCart = useCallback((serviceId: number) => {
    setCart(prev => {
      const { [serviceId]: _, ...rest } = prev;
      safeSet('sb_cart', rest);
      return rest;
    });
  }, []);

  const clearCart = useCallback(() => {
    setCart({});
    setItemData({});
    safeRemove('sb_cart');
    safeRemove('sb_items');
  }, []);

  const cartItems: CartItem[] = Object.entries(cart).map(([key, qty]) => ({
    service: Number(key),
    qty,
    name: itemData[Number(key)]?.name || `Услуга #${key}`,
    rate: itemData[Number(key)]?.rate || '0',
  }));

  const cartTotal = cartItems.reduce((sum, item) => {
    const price = parseFloat(item.rate) || 0;
    return sum + (price * 1.3) * item.qty;
  }, 0);

  return (
    <CartContext.Provider value={{ cart, cartItems, cartTotal, addToCart, updateQty, setQty, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
