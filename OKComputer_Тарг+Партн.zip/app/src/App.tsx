import { HashRouter, Routes, Route } from 'react-router-dom';
import { CartProvider } from '@/providers/cart';
import TMALayout from '@/components/TMALayout';
import Home from '@/pages/Home';
import CatalogPage from '@/pages/CatalogPage';
import CartPage from '@/pages/CartPage';
import CheckoutPage from '@/pages/CheckoutPage';
import ProfilePage from '@/pages/ProfilePage';
import AdminPage from '@/pages/AdminPage';

function App() {
  return (
    <HashRouter>
      <CartProvider>
        <TMALayout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/catalog/:platform" element={<CatalogPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin" element={<AdminPage />} />
          </Routes>
        </TMALayout>
      </CartProvider>
    </HashRouter>
  );
}

export default App;
