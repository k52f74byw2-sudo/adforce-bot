import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Wallet, ExternalLink, TrendingUp, AlertCircle, RefreshCw } from 'lucide-react';

export default function AdminPage() {
  const navigate = useNavigate();
  const [balance, setBalance] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ totalOrders: 0, todayRevenue: 0 });
  const [error, setError] = useState('');

  // Check if admin
  const tg = (window as any).Telegram?.WebApp;
  const userId = tg?.initDataUnsafe?.user?.id;
  const userName = tg?.initDataUnsafe?.user?.username || 'unknown';

  // Store admin ID on first visit
  useEffect(() => {
    if (userId) {
      const savedId = localStorage.getItem('af_admin_id');
      if (!savedId) {
        localStorage.setItem('af_admin_id', String(userId));
        localStorage.setItem('af_admin_name', userName);
      }
    }
  }, [userId, userName]);

  const savedAdminId = localStorage.getItem('af_admin_id');
  const isAdmin = !savedAdminId || savedAdminId === String(userId);

  // Load balance from bot (via sendData)
  const checkBalance = () => {
    setLoading(true);
    setError('');
    
    // Try to get balance via API proxy
    fetch('https://stream-promotion.ru/api/v2', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        key: 'roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY',
        action: 'balance',
      }),
    })
      .then(r => r.json())
      .then(data => {
        if (data.balance !== undefined) {
          setBalance(data.balance);
        } else {
          setError('Не удалось получить баланс');
        }
      })
      .catch(() => {
        // Fallback: request via bot
        if (tg?.sendData) {
          tg.sendData(JSON.stringify({ action: 'check_balance' }));
        }
        setError('CORS блокировка. Используйте бота: /balance');
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    checkBalance();
    
    // Load local stats
    const orders = JSON.parse(localStorage.getItem('af_orders') || '[]');
    const today = new Date().toDateString();
    const todayOrders = orders.filter((o: any) => o.date === today);
    setStats({
      totalOrders: orders.length,
      todayRevenue: todayOrders.reduce((s: number, o: any) => s + (o.amount || 0), 0),
    });
  }, []);

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ background: 'var(--bg-primary)' }}>
        <div className="text-center">
          <AlertCircle size={48} style={{ color: '#EF4444' }} className="mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Доступ запрещён</h2>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Эта страница только для администратора</p>
        </div>
      </div>
    );
  }

  const openTopUp = () => {
    // Open stream-promotion.ru top-up page
    window.open('https://stream-promotion.ru/addfunds', '_blank');
  };

  return (
    <div className="min-h-screen px-5 pt-6 pb-8" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <button onClick={() => navigate('/profile')} className="glass-card w-10 h-10 flex items-center justify-center active:scale-90 transition-transform cursor-pointer">
          <ChevronLeft size={18} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <h1 className="text-xl font-black tracking-tight" style={{ color: 'var(--text-primary)' }}>Админ панель</h1>
      </div>

      {/* Admin Info */}
      <div className="glass-card p-4 mb-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #2563EB, #3B82F6)' }}>
          <span className="text-white text-sm font-bold">A</span>
        </div>
        <div>
          <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>@{userName}</p>
          <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>ID: {userId || savedAdminId}</p>
        </div>
        <span className="ml-auto text-[10px] font-semibold px-2 py-1 rounded-full" style={{ background: '#EFF6FF', color: '#2563EB' }}>
          ADMIN
        </span>
      </div>

      {/* API Balance */}
      <div className="package-card p-5 mb-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-[13px] font-semibold tracking-wide uppercase" style={{ color: 'var(--text-muted)' }}>
            Баланс Stream-Promotion
          </h2>
          <button onClick={checkBalance} className="w-8 h-8 rounded-lg flex items-center justify-center active:scale-90 transition-all cursor-pointer" style={{ background: '#F1F5F9' }}>
            <RefreshCw size={14} style={{ color: 'var(--accent-blue)' }} />
          </button>
        </div>
        
        {loading ? (
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Загрузка...</p>
        ) : error ? (
          <div className="flex items-center gap-2">
            <AlertCircle size={14} style={{ color: '#EF4444' }} />
            <p className="text-sm" style={{ color: '#EF4444' }}>{error}</p>
          </div>
        ) : (
          <div className="flex items-end gap-2">
            <span className="text-[36px] font-black" style={{ color: parseFloat(balance || '0') > 100 ? '#10B981' : '#EF4444' }}>
              {balance}
            </span>
            <span className="text-lg mb-2" style={{ color: 'var(--text-muted)' }}>₽</span>
          </div>
        )}

        {parseFloat(balance || '0') < 500 && (
          <div className="mt-3 p-3 rounded-xl flex items-start gap-2" style={{ background: '#FEF2F2' }}>
            <AlertCircle size={14} style={{ color: '#EF4444' }} className="mt-0.5 shrink-0" />
            <p className="text-[12px]" style={{ color: '#EF4444' }}>
              Баланс ниже 500 ₽! Срочно пополните — заказы не будут обрабатываться.
            </p>
          </div>
        )}
      </div>

      {/* Top Up Button */}
      <button 
        onClick={openTopUp}
        className="btn-glow w-full py-4 rounded-2xl text-[16px] font-bold flex items-center justify-center gap-2 mb-6"
      >
        <Wallet size={18} /> Пополнить баланс <ExternalLink size={14} />
      </button>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="glass-card p-4 text-center">
          <TrendingUp size={18} style={{ color: 'var(--accent-blue)' }} className="mx-auto mb-2" />
          <p className="text-2xl font-black" style={{ color: 'var(--text-primary)' }}>{stats.totalOrders}</p>
          <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>Всего заказов</p>
        </div>
        <div className="glass-card p-4 text-center">
          <Wallet size={18} style={{ color: '#10B981' }} className="mx-auto mb-2" />
          <p className="text-2xl font-black" style={{ color: '#10B981' }}>{stats.todayRevenue.toFixed(0)} ₽</p>
          <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>Сегодня</p>
        </div>
      </div>

      {/* Instructions */}
      <div className="glass-card p-4">
        <h3 className="text-sm font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Как пополнить</h3>
        <div className="space-y-2">
          {[
            'Нажмите кнопку «Пополнить баланс» выше',
            'Выберите способ оплаты на сайте',
            'Введите сумму (минимум 1000 ₽)',
            'Оплатите и вернитесь сюда',
            'Нажмите 🔄 для обновления баланса',
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center shrink-0" 
                style={{ background: '#EFF6FF', color: '#2563EB' }}>
                {i + 1}
              </span>
              <p className="text-[12px]" style={{ color: 'var(--text-secondary)' }}>{step}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Alternative: via bot */}
      <div className="mt-4 p-4 rounded-2xl" style={{ background: '#F0FDF4' }}>
        <p className="text-[12px] font-semibold mb-1" style={{ color: '#059669' }}>Или через бота</p>
        <p className="text-[11px]" style={{ color: '#6B7280' }}>
          Напишите в @AdForceRussiaBot: <span style={{ fontWeight: 600 }}>/balance</span> — чтобы проверить баланс
        </p>
      </div>

      <p className="text-center text-[10px] mt-6" style={{ color: 'var(--text-muted)' }}>
        v2.2 • Админ ID: {savedAdminId || 'не установлен'}
      </p>
    </div>
  );
}
