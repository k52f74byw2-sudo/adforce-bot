import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/providers/cart';
import { Tv, Play, Zap, Radio, Globe, MessageCircle, Heart, Smartphone, Twitter, Gamepad2, Star, ShoppingCart, TrendingUp, Shield, Sparkles } from 'lucide-react';

const PLATFORMS = [
  { slug: 'twitch', name: 'Twitch', color: '#7C3AED', icon: Tv },
  { slug: 'youtube', name: 'YouTube', color: '#EF4444', icon: Play },
  { slug: 'kick', name: 'Kick', color: '#10B981', icon: Zap },
  { slug: 'trovo', name: 'Trovo', color: '#14B8A6', icon: Radio },
  { slug: 'vk', name: 'VK', color: '#2563EB', icon: Globe },
  { slug: 'telegram', name: 'Telegram', color: '#0EA5E9', icon: MessageCircle },
  { slug: 'instagram', name: 'Instagram', color: '#EC4899', icon: Heart },
  { slug: 'tiktok', name: 'TikTok', color: '#F43F5E', icon: Smartphone },
  { slug: 'twitter', name: 'X / Twitter', color: '#334155', icon: Twitter },
  { slug: 'discord', name: 'Discord', color: '#6366F1', icon: MessageCircle },
  { slug: 'facebook', name: 'Facebook', color: '#2563EB', icon: Globe },
  { slug: 'steam', name: 'Steam', color: '#059669', icon: Gamepad2 },
];

const PACKAGES = [
  { name: 'Старт', views: '1 000', price: 299, color: '#2563EB', desc: 'Базовое продвижение' },
  { name: 'Рост', views: '5 000', price: 999, color: '#3B82F6', desc: 'Таргетированная реклама' },
  { name: 'Вирус', views: '10 000', price: 1999, color: '#6366F1', desc: 'Максимальный охват' },
  { name: 'Топ', views: '50 000', price: 7999, color: '#8B5CF6', desc: 'VIP продвижение' },
];

const STATS = [
  { icon: <Star size={14} />, value: '12', label: 'Платформ' },
  { icon: <TrendingUp size={14} />, value: '24ч', label: 'Старт' },
  { icon: <Shield size={14} />, value: '100%', label: 'Гарантия' },
  { icon: <Sparkles size={14} />, value: 'AI', label: 'Таргетинг' },
];

export default function Home() {
  const navigate = useNavigate();
  const { cart } = useCart();
  const [activeTab, setActiveTab] = useState<'platforms' | 'packages'>('platforms');
  const cartCount = Object.keys(cart).length;

  return (
    <div className="min-h-screen px-5 pt-8 pb-4" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="pulse-dot" />
            <span className="text-[10px] font-medium tracking-widest uppercase" style={{ color: 'var(--text-muted)' }}>AdForce Agency</span>
          </div>
          <h1 className="text-[28px] font-black tracking-tight leading-[1.1]" style={{ color: 'var(--text-primary)' }}>
            Рекламное<br />
            <span className="gradient-text">агентство</span>
          </h1>
        </div>
        <button
          onClick={() => navigate('/cart')}
          className="glass-card w-12 h-12 flex items-center justify-center active:scale-90 transition-transform cursor-pointer relative"
        >
          <ShoppingCart size={20} style={{ color: 'var(--accent-blue)' }} />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-[#2563EB] to-[#3B82F6] text-white text-[10px] font-bold flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-2 mb-8 stagger">
        {STATS.map((s, i) => (
          <div key={i} className="glass-card p-3 text-center">
            <div className="flex justify-center mb-1.5" style={{ color: 'var(--accent-blue)' }}>{s.icon}</div>
            <p className="text-sm font-black" style={{ color: 'var(--text-primary)' }}>{s.value}</p>
            <p className="text-[9px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {[
          { key: 'platforms' as const, label: 'Платформы' },
          { key: 'packages' as const, label: 'Пакеты' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 py-3 rounded-xl text-[13px] font-semibold transition-all cursor-pointer ${
              activeTab === tab.key
                ? 'tab-glass active'
                : 'tab-glass'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Platforms Grid */}
      {activeTab === 'platforms' && (
        <div className="grid grid-cols-3 gap-3 stagger">
          {PLATFORMS.map((p) => {
            const Icon = p.icon;
            return (
              <button
                key={p.slug}
                onClick={() => navigate(`/catalog/${p.slug}`)}
                className="glass-card p-4 flex flex-col items-center text-center gap-2.5 cursor-pointer group"
              >
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                  style={{
                    background: `linear-gradient(135deg, ${p.color}12, ${p.color}05)`,
                    boxShadow: `0 2px 12px ${p.color}10`,
                  }}
                >
                  <Icon size={22} style={{ color: p.color }} />
                </div>
                <span className="text-[11px] font-semibold leading-tight" style={{ color: 'var(--text-primary)' }}>{p.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Packages */}
      {activeTab === 'packages' && (
        <div className="space-y-3 stagger">
          {PACKAGES.map((pkg, i) => (
            <button
              key={i}
              onClick={() => navigate('/cart')}
              className="w-full package-card p-5 text-left cursor-pointer active:scale-[0.98] transition-transform"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-lg font-black"
                    style={{
                      background: `linear-gradient(135deg, ${pkg.color}12, ${pkg.color}05)`,
                      color: pkg.color,
                    }}
                  >
                    {pkg.name[0]}
                  </div>
                  <div>
                    <h3 className="text-[15px] font-bold" style={{ color: 'var(--text-primary)' }}>{pkg.name}</h3>
                    <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{pkg.desc}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-black" style={{ color: pkg.color }}>{pkg.price} ₽</p>
                  <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{pkg.views} показов</p>
                </div>
              </div>
              <div className="h-1 rounded-full mt-3 overflow-hidden" style={{ background: '#F1F5F9' }}>
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${(i + 1) * 25}%`,
                    background: `linear-gradient(90deg, ${pkg.color}, ${pkg.color}90)`,
                  }}
                />
              </div>
            </button>
          ))}
        </div>
      )}

      {/* How it works */}
      <section className="mt-10 mb-6">
        <h2 className="text-lg font-bold mb-4 px-1" style={{ color: 'var(--text-primary)' }}>Как это работает</h2>
        <div className="space-y-3 stagger">
          {[
            { num: '01', title: 'Выберите пакет', desc: 'Выберите платформу и объём рекламы под ваш бюджет', color: '#2563EB' },
            { num: '02', title: 'Укажите ссылку', desc: 'Вставьте ссылку на канал, видео или стрим для продвижения', color: '#3B82F6' },
            { num: '03', title: 'Получите результат', desc: 'Реклама запускается автоматически, живые показы за 24ч', color: '#6366F1' },
          ].map((item, i) => (
            <div key={i} className="glass-card p-4 flex items-start gap-4">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-black shrink-0"
                style={{
                  background: `linear-gradient(135deg, ${item.color}12, ${item.color}05)`,
                  color: item.color,
                }}
              >
                {item.num}
              </div>
              <div>
                <h3 className="text-[14px] font-bold mb-0.5" style={{ color: 'var(--text-primary)' }}>{item.title}</h3>
                <p className="text-[12px] leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
