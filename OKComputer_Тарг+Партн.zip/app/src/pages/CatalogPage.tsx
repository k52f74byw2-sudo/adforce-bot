import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Search, ShoppingCart, ChevronLeft, X } from 'lucide-react';
import { useCart } from '@/providers/cart';
import { getPlatformInfo, fetchLocalServices, type ApiService } from '@/services/stream-api';

const REKLAMA_PACKAGES: Record<string, { name: string; views: string; price: number; desc: string; color: string }[]> = {
  twitch: [
    { name: 'Старт', views: '1 000', price: 299, desc: 'Реклама стрима в рекомендациях', color: '#2563EB' },
    { name: 'Рост', views: '5 000', price: 999, desc: 'Таргет в категории игры', color: '#3B82F6' },
    { name: 'Вирус', views: '10 000', price: 1999, desc: 'Продвижение на главной', color: '#6366F1' },
    { name: 'Топ', views: '50 000', price: 7999, desc: 'Максимальный охват + баннер', color: '#8B5CF6' },
  ],
  youtube: [
    { name: 'Старт', views: '1 000', price: 349, desc: 'Реклама в рекомендациях', color: '#2563EB' },
    { name: 'Рост', views: '5 000', price: 1199, desc: 'Таргет на аудиторию', color: '#3B82F6' },
    { name: 'Вирус', views: '10 000', price: 2299, desc: 'Продвижение в трендах', color: '#6366F1' },
    { name: 'Топ', views: '50 000', price: 8999, desc: 'Главная + поиск', color: '#8B5CF6' },
  ],
  tiktok: [
    { name: 'Старт', views: '1 000', price: 199, desc: 'Реклама в ленте For You', color: '#2563EB' },
    { name: 'Рост', views: '5 000', price: 799, desc: 'Вирусное продвижение', color: '#3B82F6' },
    { name: 'Вирус', views: '10 000', price: 1499, desc: 'Топ лента', color: '#6366F1' },
    { name: 'Топ', views: '50 000', price: 5999, desc: 'Максимальный охват', color: '#8B5CF6' },
  ],
  default: [
    { name: 'Старт', views: '1 000', price: 299, desc: 'Реклама в рекомендациях', color: '#2563EB' },
    { name: 'Рост', views: '5 000', price: 999, desc: 'Таргетированная реклама', color: '#3B82F6' },
    { name: 'Вирус', views: '10 000', price: 1999, desc: 'Максимальный охват', color: '#6366F1' },
    { name: 'Топ', views: '50 000', price: 7999, desc: 'VIP продвижение', color: '#8B5CF6' },
  ],
};

export default function CatalogPage() {
  const { platform } = useParams<{ platform: string }>();
  const navigate = useNavigate();
  const { cart, addToCart } = useCart();
  const [allServices, setAllServices] = useState<ApiService[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCart, setShowCart] = useState(false);
  const [link, setLink] = useState('');

  const info = getPlatformInfo(platform || '');
  const packages = REKLAMA_PACKAGES[platform || ''] || REKLAMA_PACKAGES.default;

  useEffect(() => {
    if (!platform) return;
    setIsLoading(true);
    fetchLocalServices(platform)
      .then(data => setAllServices(data))
      .catch(() => setAllServices([]))
      .finally(() => setIsLoading(false));
  }, [platform]);

  const filtered = allServices.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    (s.desc && s.desc.toLowerCase().includes(search.toLowerCase()))
  );

  const handleAdd = (pkg: { name: string; views: string; price: number; desc: string; color: string }, serviceId: number) => {
    addToCart(serviceId, 1, `${info.name} — ${pkg.name} (${pkg.views})`, String(pkg.price));
  };

  const handleCheckout = () => {
    if (!link.trim()) { alert('Введите ссылку на канал/видео'); return; }
    navigate('/checkout', { state: { link, platformName: info.name } });
  };

  useEffect(() => {
    const webApp = (window as any).Telegram?.WebApp;
    if (webApp?.BackButton) {
      webApp.BackButton.show();
      webApp.BackButton.onClick(() => navigate('/'));
      return () => { webApp.BackButton.hide(); };
    }
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4" style={{ background: 'var(--bg-primary)' }}>
        <div className="w-10 h-10 border-2 rounded-full animate-spin mb-4" style={{ borderColor: 'var(--border-light)', borderTopColor: 'var(--accent-blue)' }} />
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Загрузка...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-5 pt-6 pb-4" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/')} className="glass-card w-10 h-10 flex items-center justify-center active:scale-90 transition-transform cursor-pointer">
          <ChevronLeft size={18} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black tracking-tight" style={{ color: info.color }}>{info.name}</h1>
          <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{packages.length} рекламных пакета</p>
        </div>
        <button onClick={() => setShowCart(true)} className="glass-card w-10 h-10 flex items-center justify-center relative active:scale-90 transition-transform cursor-pointer">
          <ShoppingCart size={16} style={{ color: 'var(--accent-blue)' }} />
          {Object.keys(cart).length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-r from-[#2563EB] to-[#3B82F6] text-white text-[8px] font-bold flex items-center justify-center">
              {Object.keys(cart).length}
            </span>
          )}
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск услуг..."
          className="w-full h-12 input-glass pl-11 pr-4 text-sm"
        />
      </div>

      {/* Reklama Packages */}
      <div className="space-y-3 stagger">
        {packages.map((pkg, idx) => {
          const serviceId = (platform ? platform.charCodeAt(0) : 0) * 1000 + idx;
          const inCart = cart[serviceId] || 0;
          return (
            <div key={idx} className="package-card p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-black"
                    style={{
                      background: `linear-gradient(135deg, ${pkg.color}12, ${pkg.color}05)`,
                      color: pkg.color,
                    }}
                  >
                    {pkg.name[0]}
                  </div>
                  <div>
                    <h3 className="text-[15px] font-bold" style={{ color: 'var(--text-primary)' }}>{pkg.name}</h3>
                    <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{pkg.desc}</p>
                    <span
                      className="inline-block text-[10px] font-semibold mt-1 px-2.5 py-0.5 rounded-full"
                      style={{ background: `${pkg.color}10`, color: pkg.color }}
                    >
                      {pkg.views} показов
                    </span>
                  </div>
                </div>
                <span className="text-xl font-black" style={{ color: pkg.color }}>{pkg.price} ₽</span>
              </div>

              {inCart > 0 ? (
                <div className="flex items-center gap-3">
                  <span className="text-[13px] font-semibold flex items-center gap-1.5" style={{ color: 'var(--success)' }}>
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--success)' }} />
                    В заказе
                  </span>
                </div>
              ) : (
                <button onClick={() => handleAdd(pkg, serviceId)}
                  className="w-full py-3 rounded-xl text-[13px] font-bold cursor-pointer active:scale-[0.98] transition-all"
                  style={{
                    background: '#F8FAFC',
                    color: 'var(--text-primary)',
                    border: '1px solid var(--border-light)',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.background = 'linear-gradient(135deg, #2563EB, #3B82F6)';
                    e.currentTarget.style.color = '#FFFFFF';
                    e.currentTarget.style.borderColor = 'transparent';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.background = '#F8FAFC';
                    e.currentTarget.style.color = 'var(--text-primary)';
                    e.currentTarget.style.borderColor = 'var(--border-light)';
                  }}
                >
                  Добавить в заказ
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Services List */}
      {filtered.length > 0 && (
        <div className="mt-6">
          <h3 className="text-sm font-bold mb-3" style={{ color: 'var(--text-secondary)' }}>Дополнительные опции</h3>
          <div className="space-y-2">
            {filtered.slice(0, 10).map((s) => {
              const inCart = cart[s.service] || 0;
              return (
                <div key={s.service} className="glass-card p-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0 mr-3">
                      <p className="text-[13px] font-medium truncate" style={{ color: 'var(--text-primary)' }}>{s.name}</p>
                      <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{s.desc || s.category}</p>
                    </div>
                    {inCart > 0 ? (
                      <span className="text-[11px] font-semibold" style={{ color: 'var(--success)' }}>В заказе</span>
                    ) : (
                      <button onClick={() => addToCart(s.service, 1, s.name, s.rate)}
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-lg font-bold cursor-pointer active:scale-90 transition-all"
                        style={{
                          background: '#F1F5F9',
                          color: 'var(--accent-blue)',
                          border: '1px solid var(--border-light)',
                        }}>
                        +
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Cart Overlay */}
      {showCart && (
        <div className="fixed inset-0 z-50 pt-6 px-5 pb-24 overflow-auto" style={{ background: 'rgba(255,255,255,0.98)', backdropFilter: 'blur(20px)' }}>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-black" style={{ color: 'var(--text-primary)' }}>Корзина</h2>
            <button onClick={() => setShowCart(false)} className="glass-card w-10 h-10 flex items-center justify-center cursor-pointer active:scale-90 transition-transform">
              <X size={16} style={{ color: 'var(--text-secondary)' }} />
            </button>
          </div>

          <div className="mb-6">
            <label className="text-[10px] font-medium tracking-widest uppercase mb-2 block" style={{ color: 'var(--text-muted)' }}>Ссылка на канал/видео *</label>
            <input
              type="text" value={link} onChange={e => setLink(e.target.value)} placeholder="https://..."
              className="w-full h-14 input-glass px-4 text-base"
            />
          </div>

          <button onClick={handleCheckout}
            className="btn-glow w-full py-4 rounded-2xl text-[15px] font-bold">
            Перейти к оплате
          </button>
        </div>
      )}
    </div>
  );
}
