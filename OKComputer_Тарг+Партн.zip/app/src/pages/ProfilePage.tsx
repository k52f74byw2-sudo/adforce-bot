import { User, Shield, Clock, HelpCircle, Zap, Globe, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ProfilePage() {
  const navigate = useNavigate();

  // Check if admin
  const tg = (window as any).Telegram?.WebApp;
  const userId = tg?.initDataUnsafe?.user?.id;
  const savedAdminId = localStorage.getItem('af_admin_id');
  const isAdmin = !savedAdminId || savedAdminId === String(userId);

  const menuItems = [
    { icon: <Shield size={20} />, label: 'Гарантия качества', desc: 'Все заказы с гарантией результата', color: '#10B981' },
    { icon: <Clock size={20} />, label: 'Скорость запуска', desc: 'Реклама стартует в течение 24 часов', color: '#2563EB' },
    { icon: <Zap size={20} />, label: 'AI-таргетинг', desc: 'Автоматический подбор аудитории', color: '#6366F1' },
    { icon: <Globe size={20} />, label: '12 платформ', desc: 'Продвижение везде', color: '#3B82F6' },
    { icon: <HelpCircle size={20} />, label: 'Поддержка', desc: 'Написать в поддержку', color: '#F59E0B' },
  ];

  return (
    <div className="min-h-screen px-5 pt-8 pb-4" style={{ background: 'var(--bg-primary)' }}>
      {/* Profile Header */}
      <div className="text-center mb-8">
        <div
          className="w-24 h-24 rounded-[28px] mx-auto mb-4 flex items-center justify-center"
          style={{
            background: 'linear-gradient(135deg, rgba(37,99,235,0.1), rgba(59,130,246,0.08))',
            boxShadow: '0 8px 32px rgba(37,99,235,0.1), inset 0 1px 0 rgba(255,255,255,0.5)',
          }}
        >
          <User size={40} style={{ color: 'var(--accent-blue)' }} />
        </div>
        <h2 className="text-[22px] font-black tracking-tight" style={{ color: 'var(--text-primary)' }}>AdForce</h2>
        <p className="text-[13px] mt-1" style={{ color: 'var(--text-muted)' }}>Рекламное агентство</p>
      </div>

      {/* Admin Panel Button — ONLY for admin */}
      {isAdmin && (
        <button
          onClick={() => navigate('/admin')}
          className="w-full mb-4 p-4 rounded-2xl flex items-center gap-4 text-left cursor-pointer active:scale-[0.98] transition-transform"
          style={{ background: 'linear-gradient(135deg, #2563EB, #3B82F6)' }}
        >
          <div className="w-11 h-11 rounded-[14px] flex items-center justify-center shrink-0" style={{ background: 'rgba(255,255,255,0.2)' }}>
            <Settings size={20} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[14px] font-semibold text-white">Админ панель</p>
            <p className="text-[12px]" style={{ color: 'rgba(255,255,255,0.7)' }}>Баланс API, пополнение, статистика</p>
          </div>
          <span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{ background: 'rgba(255,255,255,0.2)', color: 'white' }}>
            ADMIN
          </span>
        </button>
      )}

      {/* Menu */}
      <div className="space-y-2.5">
        {menuItems.map((item, i) => (
          <button
            key={i}
            onClick={() => alert(`${item.label} — в разработке`)}
            className="w-full glass-card p-4 flex items-center gap-4 text-left cursor-pointer active:scale-[0.98] transition-transform"
          >
            <div
              className="w-11 h-11 rounded-[14px] flex items-center justify-center shrink-0"
              style={{
                background: `linear-gradient(135deg, ${item.color}10, ${item.color}04)`,
              }}
            >
              <span style={{ color: item.color }}>{item.icon}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[14px] font-semibold" style={{ color: 'var(--text-primary)' }}>{item.label}</p>
              <p className="text-[12px]" style={{ color: 'var(--text-muted)' }}>{item.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Footer */}
      <div className="mt-8 glass-card p-5 text-center">
        <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: 'var(--text-muted)' }}>Powered by</p>
        <p className="text-[14px] font-bold gradient-text">AdForce Agency</p>
        <p className="text-[11px] mt-1.5" style={{ color: 'var(--text-muted)' }}>7500+ услуг • 12 платформ • 24/7</p>
      </div>

      {/* Version */}
      <p className="text-center text-[10px] mt-6" style={{ color: 'var(--text-muted)' }}>v2.3 • Admin Panel</p>
    </div>
  );
}
