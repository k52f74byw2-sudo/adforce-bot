import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronLeft, Star, Bitcoin, Wallet, Loader, CheckCircle } from 'lucide-react';
import { useCart } from '@/providers/cart';

interface CartItemData {
  service: number;
  name: string;
  qty: number;
  rate: string;
  total: number;
}

type PaymentMethod = 'stars' | 'crypto' | 'wallet';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { cartItems: globalCartItems, cartTotal: globalCartTotal, clearCart } = useCart();

  const state = location.state as { cartItems?: CartItemData[]; cartTotal?: number; link?: string; platformName?: string } | null;

  const items = state?.cartItems || globalCartItems.map(c => ({
    service: c.service, name: c.name, qty: c.qty, rate: c.rate,
    total: (parseFloat(c.rate) * 1.3) * c.qty,
  }));
  const total = state?.cartTotal || globalCartTotal;

  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('stars');

  const starsAmount = Math.max(Math.ceil(total / 1.3), 1);
  const usdtAmount = Math.max(total / 90, 0.5);

  const handlePay = () => {
    setProcessing(true);
    const tg = (window as any).Telegram?.WebApp;

    if (tg?.sendData) {
      tg.sendData(JSON.stringify({
        action: 'create_invoice',
        method: paymentMethod,
        amount: paymentMethod === 'stars' ? starsAmount : paymentMethod === 'crypto' ? usdtAmount : Math.ceil(total / 90),
        currency: paymentMethod === 'stars' ? 'XTR' : 'USDT',
        rubTotal: total,
        link: state?.link || '',
        items: items.map(i => ({ service: i.service, name: i.name, qty: i.qty })),
      }));
    }

    setSuccess(true);
    clearCart();
    setTimeout(() => {
      if (tg?.close) tg.close();
    }, 3000);
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6" style={{ background: 'var(--bg-primary)' }}>
        <div className="text-center">
          <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6"
            style={{ background: 'linear-gradient(135deg, rgba(37,99,235,0.1), rgba(37,99,235,0.05))', boxShadow: '0 0 40px rgba(37,99,235,0.1)' }}>
            <CheckCircle size={48} style={{ color: 'var(--accent-blue)' }} />
          </div>
          <h2 className="text-[28px] font-black mb-2" style={{ color: 'var(--text-primary)' }}>Заказ создан!</h2>
          <p className="text-[14px] max-w-[260px] mx-auto leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            Перейдите в бот <span style={{ color: 'var(--accent-blue)', fontWeight: 600 }}>@AdForceRussiaBot</span> для завершения оплаты
          </p>
        </div>
      </div>
    );
  }

  const methods: { key: PaymentMethod; label: string; sub: string; icon: typeof Star }[] = [
    { key: 'stars', label: 'Telegram Stars', sub: `≈ ${starsAmount.toLocaleString('ru')} ⭐`, icon: Star },
    { key: 'wallet', label: 'Telegram Wallet', sub: `≈ ${usdtAmount.toFixed(2)} USDT / TON`, icon: Wallet },
    { key: 'crypto', label: 'CryptoBot / Вручную', sub: `≈ ${usdtAmount.toFixed(2)} USDT`, icon: Bitcoin },
  ];

  return (
    <div className="min-h-screen px-5 pt-6 pb-8" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <button onClick={() => navigate(-1)} className="glass-card w-10 h-10 flex items-center justify-center active:scale-90 transition-transform cursor-pointer">
          <ChevronLeft size={18} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <h1 className="text-xl font-black tracking-tight" style={{ color: 'var(--text-primary)' }}>Оплата</h1>
      </div>

      {/* Order Summary */}
      <div className="package-card p-5 mb-5">
        <h2 className="text-[13px] font-semibold mb-3 tracking-wide uppercase" style={{ color: 'var(--text-muted)' }}>Ваш заказ</h2>
        <div className="space-y-2.5 max-h-48 overflow-auto mb-4">
          {items.map(item => (
            <div key={item.service} className="flex items-center justify-between py-2 last:border-0" style={{ borderBottom: '1px solid var(--border-light)' }}>
              <span className="text-[13px] truncate flex-1 mr-3" style={{ color: 'var(--text-secondary)' }}>{item.name}</span>
              <span className="text-[14px] font-bold" style={{ color: 'var(--text-primary)' }}>{item.qty} шт</span>
            </div>
          ))}
        </div>
        {state?.link && (
          <div className="pt-3 mb-3" style={{ borderTop: '1px solid var(--border-light)' }}>
            <p className="text-[10px] uppercase tracking-wider mb-1" style={{ color: 'var(--text-muted)' }}>Ссылка</p>
            <p className="text-[12px] break-all" style={{ color: 'var(--accent-blue)' }}>{state.link}</p>
          </div>
        )}
        <div className="pt-4 flex items-center justify-center" style={{ borderTop: '1px solid var(--border-light)' }}>
          <div className="text-center">
            <span className="text-[15px] block mb-1" style={{ color: 'var(--text-muted)' }}>Итого</span>
            <span className="text-[32px] font-black gradient-text">{total.toFixed(0)} ₽</span>
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className="mb-6">
        <h2 className="text-[13px] font-semibold mb-3 tracking-wide uppercase" style={{ color: 'var(--text-muted)' }}>Способ оплаты</h2>

        {methods.map((m) => {
          const Icon = m.icon;
          const isActive = paymentMethod === m.key;
          return (
            <button key={m.key} onClick={() => setPaymentMethod(m.key)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border mb-3 transition-all cursor-pointer ${
                isActive ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-100'
              }`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isActive ? 'bg-blue-100' : 'bg-gray-50'}`}>
                <Icon size={22} style={{ color: isActive ? 'var(--accent-blue)' : 'var(--text-muted)' }} />
              </div>
              <div className="flex-1 text-left">
                <p className="text-[15px] font-semibold" style={{ color: 'var(--text-primary)' }}>{m.label}</p>
                <p className="text-[12px]" style={{ color: 'var(--text-muted)' }}>{m.sub}</p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isActive ? 'border-blue-500' : 'border-gray-200'}`}>
                {isActive && <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Pay Button */}
      <button onClick={handlePay} disabled={processing}
        className="btn-glow w-full py-4 rounded-2xl text-[16px] font-bold disabled:opacity-40 flex items-center justify-center gap-2">
        {processing ? (
          <><Loader size={18} className="animate-spin" /> Обработка...</>
        ) : paymentMethod === 'stars' ? (
          <><Star size={18} /> Оплатить {starsAmount.toLocaleString('ru')} ⭐</>
        ) : paymentMethod === 'wallet' ? (
          <><Wallet size={18} /> Оплатить через Wallet</>
        ) : (
          <><Bitcoin size={18} /> Оплатить {usdtAmount.toFixed(2)} USDT</>
        )}
      </button>

      <p className="text-center text-[11px] mt-4" style={{ color: 'var(--text-muted)' }}>
        После нажатия вы перейдёте в бот для завершения оплаты
      </p>
    </div>
  );
}
