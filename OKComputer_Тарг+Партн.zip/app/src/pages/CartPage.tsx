import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, Trash2, ChevronRight } from 'lucide-react';
import { useCart } from '@/providers/cart';
import { calculateTotal, formatPrice } from '@/services/stream-api';

export default function CartPage() {
  const navigate = useNavigate();
  const { cartItems, cartTotal, removeFromCart, clearCart } = useCart();
  const [link, setLink] = useState(() => localStorage.getItem('sb_link') || '');

  const handleCheckout = () => {
    if (!link.trim()) { alert('Введите ссылку на канал/видео'); return; }
    if (cartItems.length === 0) return;
    localStorage.setItem('sb_link', link);
    navigate('/checkout', {
      state: {
        cartItems: cartItems.map(c => ({
          service: c.service,
          name: c.name,
          qty: c.qty,
          rate: c.rate,
          total: calculateTotal(c.rate, c.qty),
        })),
        cartTotal,
        link,
        platformName: 'Mixed',
        platformColor: '#2563EB',
      },
    });
  };

  return (
    <div className="min-h-screen px-5 pt-8 pb-4" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-[28px] font-black tracking-tight" style={{ color: 'var(--text-primary)' }}>Заказы</h1>
          <p className="text-[12px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{cartItems.length} позиций</p>
        </div>
        {cartItems.length > 0 && (
          <button onClick={clearCart} className="text-[12px] cursor-pointer flex items-center gap-1.5" style={{ color: '#EF4444' }}>
            <Trash2 size={14} /> Очистить
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center mb-5" style={{ background: '#F8FAFC', border: '1px solid var(--border-light)' }}>
            <ShoppingCart size={32} style={{ color: 'var(--text-muted)' }} />
          </div>
          <p className="text-[15px] mb-1" style={{ color: 'var(--text-secondary)' }}>Корзина пуста</p>
          <p className="text-[12px] mb-8" style={{ color: 'var(--text-muted)' }}>Добавьте рекламные пакеты</p>
          <button onClick={() => navigate('/')} className="btn-glow px-8 py-3.5 rounded-2xl text-[14px]">
            Перейти к услугам
          </button>
        </div>
      ) : (
        <>
          {/* Link Input */}
          <div className="mb-6">
            <label className="text-[10px] font-medium tracking-widest uppercase mb-2 block" style={{ color: 'var(--text-muted)' }}>Ссылка на канал/видео *</label>
            <input
              type="text"
              value={link}
              onChange={e => { setLink(e.target.value); localStorage.setItem('sb_link', e.target.value); }}
              placeholder="https://twitch.tv/username"
              className="w-full h-14 input-glass px-4 text-base"
            />
          </div>

          {/* Items */}
          <div className="space-y-3 mb-8">
            {cartItems.map(item => (
              <div key={item.service} className="package-card p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0 mr-4">
                    <p className="text-[14px] font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{item.name}</p>
                    <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{formatPrice(item.rate)} / пакет</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-[17px] font-black" style={{ color: 'var(--text-primary)' }}>{(parseFloat(item.rate) * 1.3 * item.qty).toFixed(0)} ₽</span>
                    <button onClick={() => removeFromCart(item.service)} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer active:scale-90 transition-all" style={{ background: 'rgba(239,68,68,0.08)' }}>
                      <Trash2 size={14} style={{ color: '#EF4444' }} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="glass-card p-5 mb-6">
            <div className="flex items-center justify-between">
              <span className="text-[15px]" style={{ color: 'var(--text-muted)' }}>Итого</span>
              <span className="text-[28px] font-black gradient-text">{cartTotal.toFixed(0)} ₽</span>
            </div>
          </div>

          <button onClick={handleCheckout} className="btn-glow w-full py-4 rounded-2xl text-[15px] font-bold flex items-center justify-center gap-2">
            Оформить заказ <ChevronRight size={18} />
          </button>
        </>
      )}
    </div>
  );
}
