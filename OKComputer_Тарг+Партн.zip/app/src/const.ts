export const APP_NAME = 'StreamBoost';
export const API_BASE = 'https://stream-promotion.ru/api/v2';
export const MARKUP_PERCENT = 30;
