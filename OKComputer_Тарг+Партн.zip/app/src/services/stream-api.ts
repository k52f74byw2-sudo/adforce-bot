// ─── Stream-Promotion.ru API Client ──────────────────
// Loads services from static JSON files (data/{platform}.json)
// Price markup (+30%) applied client-side from base rate

export interface ApiService {
  service: number;
  name: string;
  category: string;
  rate: string;
  min: string;
  max: string;
  type: string;
  desc: string;
  dripfeed: boolean;
  refill: boolean;
  cancel: boolean;
}

export const MARKUP_MULTIPLIER = 1.30;

// ─── Local Data Loading ──────────────────────────────

export async function fetchLocalServices(platform: string): Promise<ApiService[]> {
  const response = await fetch(`./data/${platform}.json`);
  if (!response.ok) throw new Error(`Failed to load ${platform}: ${response.status}`);
  const data = await response.json();
  return data.map((s: any): ApiService => ({
    service: Number(s.service),
    name: String(s.name || ''),
    category: String(s.category || 'Другие'),
    rate: String(s.rate || '0'),
    min: String(s.min || '0'),
    max: String(s.max || '0'),
    type: String(s.type || 'default'),
    desc: String(s.desc || ''),
    dripfeed: Boolean(s.dripfeed),
    refill: Boolean(s.refill),
    cancel: Boolean(s.cancel),
  }));
}

export async function fetchLocalSummary(): Promise<Record<string, number>> {
  const response = await fetch('./data/summary.json');
  if (!response.ok) return {};
  return await response.json();
}

// ─── Platform Info ───────────────────────────────────

export function getPlatformInfo(slug: string): { name: string; color: string } {
  const map: Record<string, { name: string; color: string }> = {
    twitch: { name: 'Twitch', color: '#9146FF' },
    youtube: { name: 'YouTube', color: '#FF0000' },
    kick: { name: 'Kick', color: '#53FC18' },
    trovo: { name: 'Trovo', color: '#1DD3A5' },
    vk: { name: 'VK Видео', color: '#0077FF' },
    telegram: { name: 'Telegram', color: '#0088CC' },
    instagram: { name: 'Instagram', color: '#E4405F' },
    tiktok: { name: 'TikTok', color: '#FF0050' },
    twitter: { name: 'Twitter / X', color: '#000000' },
    discord: { name: 'Discord', color: '#5865F2' },
    facebook: { name: 'Facebook', color: '#1877F2' },
    steam: { name: 'Steam', color: '#1b2838' },
  };
  return map[slug] || { name: slug, color: '#00E5FF' };
}

export function categoryToPlatform(category: string): string {
  const cat = category.toLowerCase();
  if (cat.includes('twitch')) return 'twitch';
  if (cat.includes('youtube') || cat.includes('ютуб')) return 'youtube';
  if (cat.includes('kick')) return 'kick';
  if (cat.includes('trovo')) return 'trovo';
  if (cat.includes('vk') || cat.includes('вконтакте') || cat.includes('вк ')) return 'vk';
  if (cat.includes('telegram') || cat.includes('телеграм')) return 'telegram';
  if (cat.includes('instagram') || cat.includes('инстаграм')) return 'instagram';
  if (cat.includes('tiktok') || cat.includes('тикток')) return 'tiktok';
  if (cat.includes('twitter') || cat.includes('твиттер') || cat.includes(' x ')) return 'twitter';
  if (cat.includes('discord')) return 'discord';
  if (cat.includes('facebook') || cat.includes('фейсбук')) return 'facebook';
  if (cat.includes('steam')) return 'steam';
  return 'other';
}

// ─── Price Helpers ───────────────────────────────────

// Базовая цена API (без наценки) - для отображения зачёркнутой
export function formatBasePrice(rate: string): string {
  const pricePer1000 = parseFloat(rate);
  if (isNaN(pricePer1000) || pricePer1000 <= 0) return '0.00 ₽';
  return `${pricePer1000.toFixed(2)} ₽`;
}

// Цена с +30% наценкой - финальная для пользователя
export function formatPrice(rate: string): string {
  const pricePer1000 = parseFloat(rate);
  if (isNaN(pricePer1000) || pricePer1000 <= 0) return '0.00 ₽';
  const finalPrice = pricePer1000 * MARKUP_MULTIPLIER;
  return `${finalPrice.toFixed(2)} ₽`;
}

export function getUnitPrice(rate: string): number {
  const price = parseFloat(rate);
  if (isNaN(price) || price <= 0) return 0;
  return price * MARKUP_MULTIPLIER;
}

export function calculateTotal(rate: string, qty: number): number {
  return getUnitPrice(rate) * qty;
}

export function formatTotal(amount: number): string {
  return `${amount.toFixed(2)} ₽`;
}
