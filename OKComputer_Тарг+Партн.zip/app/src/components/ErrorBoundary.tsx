import { Component, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: string;
}

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(err: Error): State {
    return { hasError: true, error: err.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0a0a0f] flex flex-col items-center justify-center px-6 text-center">
          <div className="text-4xl mb-4">&#128165;</div>
          <h2 className="text-lg font-bold mb-2">Что-то пошло не так</h2>
          <p className="text-sm text-[#6b7280] mb-4">{this.state.error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-[#00E5FF] to-[#00B8FF] text-[#0a0a0f]"
          >
            Перезагрузить
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
