import { type ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Home, ShoppingCart, User } from 'lucide-react';

export default function TMALayout({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();

  const hideNav = location.pathname === '/checkout';

  const navItems = [
    { path: '/', icon: Home, label: 'Главная' },
    { path: '/cart', icon: ShoppingCart, label: 'Заказы' },
    { path: '/profile', icon: User, label: 'Профиль' },
  ];

  return (
    <div className="min-h-screen relative overflow-x-hidden" style={{ background: '#F0F4F8', color: '#0F172A' }}>
      {/* Subtle blue background gradient */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full" style={{ background: 'rgba(37,99,235,0.04)', filter: 'blur(120px)' }} />
        <div className="absolute bottom-1/4 right-0 w-80 h-80 rounded-full" style={{ background: 'rgba(59,130,246,0.03)', filter: 'blur(100px)' }} />
        <div className="absolute top-1/2 left-0 w-64 h-64 rounded-full" style={{ background: 'rgba(99,102,241,0.03)', filter: 'blur(80px)' }} />
      </div>

      <main className={`relative z-10 ${!hideNav ? 'pb-24' : ''}`}>
        {children}
      </main>

      {!hideNav && (
        <nav className="fixed bottom-0 left-0 right-0 z-50" style={{ background: '#FFFFFF', borderTop: '1px solid #E2E8F0', boxShadow: '0 -2px 12px rgba(0,0,0,0.04)' }}>
          <div className="flex items-center justify-around py-2 max-w-lg mx-auto">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex flex-col items-center gap-0.5 px-6 py-2 rounded-2xl transition-all duration-300 cursor-pointer ${
                    isActive ? 'text-blue-600' : 'text-slate-400 hover:text-slate-500'
                  }`}
                >
                  <div className={`transition-all duration-300 ${isActive ? 'scale-110' : ''}`}>
                    <item.icon size={22} strokeWidth={isActive ? 2.5 : 1.5} />
                  </div>
                  <span className="text-[9px] font-medium tracking-wide">{item.label}</span>
                </button>
              );
            })}
          </div>
          <div className="h-[env(safe-area-inset-bottom)]" />
        </nav>
      )}
    </div>
  );
}
