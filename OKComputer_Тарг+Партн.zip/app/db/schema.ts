import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  emailVerified: mysqlEnum("emailVerified", ["yes", "no"]).default("no").notNull(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Email Verification ────────────────────────────────

export const emailVerificationCodes = mysqlTable("email_verification_codes", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  code: varchar("code", { length: 6 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  used: mysqlEnum("used", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailVerificationCode = typeof emailVerificationCodes.$inferSelect;
export type InsertEmailVerificationCode = typeof emailVerificationCodes.$inferInsert;

export const campaigns = mysqlTable("campaigns", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  goal: varchar("goal", { length: 255 }).notNull(),
  channels: text("channels").notNull(),
  geo: varchar("geo", { length: 255 }),
  ageFrom: int("ageFrom"),
  ageTo: int("ageTo"),
  gender: varchar("gender", { length: 50 }),
  schedule: varchar("schedule", { length: 255 }),
  bidType: varchar("bidType", { length: 50 }).notNull(),
  duration: int("duration").notNull(),
  budget: varchar("budget", { length: 50 }).notNull(),
  status: mysqlEnum("status", [
    "pending",
    "configuring",
    "launched",
    "paused",
    "completed",
    "cancelled",
  ])
    .default("pending")
    .notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  forecastImpressions: int("forecastImpressions"),
  forecastClicks: int("forecastClicks"),
  forecastLeads: int("forecastLeads"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

// ─── CRM ──────────────────────────────────────────────

export const clients = mysqlTable("clients", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).unique(),
  phone: varchar("phone", { length: 50 }),
  company: varchar("company", { length: 255 }),
  source: varchar("source", { length: 255 }),
  status: mysqlEnum("status", [
    "lead",
    "contact",
    "negotiation",
    "contract",
    "client",
    "lost",
  ])
    .default("lead")
    .notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Client = typeof clients.$inferSelect;
export type InsertClient = typeof clients.$inferInsert;

export const clientNotes = mysqlTable("client_notes", {
  id: serial("id").primaryKey(),
  clientId: bigint("clientId", { mode: "number", unsigned: true }).notNull(),
  content: text("content").notNull(),
  createdBy: varchar("createdBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ClientNote = typeof clientNotes.$inferSelect;
export type InsertClientNote = typeof clientNotes.$inferInsert;

export const crmActivities = mysqlTable("crm_activities", {
  id: serial("id").primaryKey(),
  clientId: bigint("clientId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["call", "email", "meeting", "note", "campaign"])
    .default("note")
    .notNull(),
  content: text("content").notNull(),
  createdBy: varchar("createdBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CrmActivity = typeof crmActivities.$inferSelect;
export type InsertCrmActivity = typeof crmActivities.$inferInsert;

// ─── Subscriptions ────────────────────────────────────

export const subscriptionPlans = mysqlTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  price: int("price").notNull(),
  interval: mysqlEnum("interval", ["monthly", "yearly"]).default("monthly").notNull(),
  features: text("features").notNull(),
  maxCampaigns: int("maxCampaigns").default(1).notNull(),
  maxEmails: int("maxEmails").default(100).notNull(),
  hasAdvancedTargeting: mysqlEnum("hasAdvancedTargeting", ["yes", "no"]).default("no").notNull(),
  hasPrioritySupport: mysqlEnum("hasPrioritySupport", ["yes", "no"]).default("no").notNull(),
  hasAnalytics: mysqlEnum("hasAnalytics", ["yes", "no"]).default("no").notNull(),
  isActive: mysqlEnum("isActive", ["yes", "no"]).default("yes").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;

export const subscriptions = mysqlTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  planId: bigint("planId", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired", "pending"])
    .default("pending")
    .notNull(),
  startDate: timestamp("startDate").defaultNow().notNull(),
  endDate: timestamp("endDate").notNull(),
  autoRenew: mysqlEnum("autoRenew", ["yes", "no"]).default("yes").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

export const payments = mysqlTable("payments", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  subscriptionId: bigint("subscriptionId", { mode: "number", unsigned: true }),
  amount: int("amount").notNull(),
  currency: varchar("currency", { length: 10 }).default("RUB").notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"])
    .default("pending")
    .notNull(),
  description: varchar("description", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// ─── Stream Orders ────────────────────────────────────
// Tracks orders placed through stream-promotion.ru API

export const orders = mysqlTable("orders", {
  id: serial("id").primaryKey(),
  // The order ID returned by stream-promotion.ru API
  apiOrderId: bigint("apiOrderId", { mode: "number", unsigned: true }).notNull(),
  // Service ID from the SMM panel
  serviceId: int("serviceId").notNull(),
  // Target link (stream URL, profile, etc.)
  link: varchar("link", { length: 2000 }).notNull(),
  // Quantity ordered
  quantity: int("quantity").notNull(),
  // Order status
  status: mysqlEnum("status", [
    "pending",
    "in_progress",
    "partial",
    "completed",
    "canceled",
    "error",
  ])
    .default("pending")
    .notNull(),
  // Payment reference
  paymentId: varchar("paymentId", { length: 255 }),
  // Error message if failed
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ─── Case Studies ─────────────────────────────────────

export const caseStudies = mysqlTable("case_studies", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  clientName: varchar("clientName", { length: 255 }),
  industry: varchar("industry", { length: 100 }).notNull(),
  channel: varchar("channel", { length: 100 }).notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }),
  budget: int("budget").notNull(),
  duration: int("duration").notNull(),
  
  // Before metrics
  beforeCtr: varchar("beforeCtr", { length: 20 }),
  beforeCpc: int("beforeCpc"),
  beforeConversions: int("beforeConversions"),
  beforeRoi: varchar("beforeRoi", { length: 20 }),
  
  // After metrics
  afterCtr: varchar("afterCtr", { length: 20 }),
  afterCpc: int("afterCpc"),
  afterConversions: int("afterConversions"),
  afterRoi: varchar("afterRoi", { length: 20 }),
  
  // Key results
  impressions: int("impressions"),
  clicks: int("clicks"),
  leads: int("leads"),
  sales: int("sales"),
  revenue: int("revenue"),
  
  // Strategy description
  strategy: text("strategy"),
  audience: text("audience"),
  creatives: text("creatives"),
  optimization: text("optimization"),
  
  // Tips for similar campaigns
  tips: text("tips"),
  
  isFeatured: mysqlEnum("isFeatured", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CaseStudy = typeof caseStudies.$inferSelect;
export type InsertCaseStudy = typeof caseStudies.$inferInsert;

// ─── Referrals ────────────────────────────────────────

export const referrals = mysqlTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: bigint("referrerId", { mode: "number", unsigned: true }).notNull(),
  referralCode: varchar("referralCode", { length: 32 }).notNull().unique(),
  referredEmail: varchar("referredEmail", { length: 320 }),
  referredName: varchar("referredName", { length: 255 }),
  status: mysqlEnum("status", ["pending", "registered", "activated", "paid"])
    .default("pending")
    .notNull(),
  rewardAmount: int("rewardAmount").default(0).notNull(),
  source: varchar("source", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

// ─── Campaign Reports ─────────────────────────────────

export const campaignReports = mysqlTable("campaign_reports", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  campaignId: bigint("campaignId", { mode: "number", unsigned: true }),
  campaignName: varchar("campaignName", { length: 255 }).notNull(),
  channel: varchar("channel", { length: 100 }).notNull(),
  status: mysqlEnum("status", ["draft", "ready", "sent", "archived"])
    .default("draft")
    .notNull(),

  // Period
  reportPeriodStart: timestamp("reportPeriodStart").notNull(),
  reportPeriodEnd: timestamp("reportPeriodEnd").notNull(),

  // Core metrics
  impressions: int("impressions").default(0).notNull(),
  clicks: int("clicks").default(0).notNull(),
  ctr: varchar("ctr", { length: 20 }).default("0%").notNull(),
  cpc: int("cpc").default(0).notNull(),
  spend: int("spend").default(0).notNull(),

  // Conversion metrics
  conversions: int("conversions").default(0).notNull(),
  cpa: int("cpa").default(0).notNull(),
  conversionRate: varchar("conversionRate", { length: 20 }).default("0%").notNull(),

  // Revenue & ROI
  revenue: int("revenue").default(0).notNull(),
  roi: varchar("roi", { length: 20 }).default("0%").notNull(),
  roas: varchar("roas", { length: 20 }).default("0x").notNull(),

  // Engagement
  avgSessionDuration: int("avgSessionDuration").default(0),
  bounceRate: varchar("bounceRate", { length: 20 }).default("0%"),
  uniqueUsers: int("uniqueUsers").default(0),

  // Daily stats JSON
  dailyStats: text("dailyStats"),

  // Charts data
  chartsData: text("chartsData"),

  // Report content
  executiveSummary: text("executiveSummary"),
  recommendations: text("recommendations"),
  notes: text("notes"),

  // Delivery
  clientEmail: varchar("clientEmail", { length: 320 }),
  sentAt: timestamp("sentAt"),

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type CampaignReport = typeof campaignReports.$inferSelect;
export type InsertCampaignReport = typeof campaignReports.$inferInsert;
