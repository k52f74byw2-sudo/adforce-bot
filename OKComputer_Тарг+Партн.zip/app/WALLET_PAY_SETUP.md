# Настройка Telegram Wallet Pay

## Что такое Wallet Pay?

**Wallet Pay** — это платёжная система внутри Telegram, которая позволяет принимать криптовалюту (USDT, TON, BTC) напрямую в вашем боте. Пользователи оплачивают одним нажатием через свой Telegram Wallet.

## Как подключить

### Шаг 1 — Получить токен Wallet Pay

1. Откройте **@wallet** в Telegram
2. Перейдите в **Wallet Pay** (раздел для продавцов)
3. Нажмите **"Создать приложение"**
4. Введите название: **AdForce**
5. Получите **API Key** (начинается с `wpay_...`)

### Шаг 2 — Установить токен в бота

#### Для Heroku:
```bash
heroku config:set WALLET_PAY_TOKEN="ваш_wpay_токен" --app adforce-russia-bot
```

#### Для локального запуска:
```bash
export WALLET_PAY_TOKEN="ваш_wpay_токен"
python bot.py
```

### Шаг 3 — Перезапустить бота

```bash
heroku ps:restart worker --app adforce-russia-bot
```

## Как это работает для пользователя

```
1. Пользователь выбирает услуги в Mini App
2. Переходит к оплате
3. Выбирает "Telegram Wallet"
4. Нажимает "Оплатить через Wallet"
5. Данные отправляются в бот
6. Бот создаёт инвойс через Wallet Pay API
7. Пользователю приходит ссылка на оплату
8. Пользователь нажимает → открывается Wallet
9. Оплата в 1 клик!
10. Бот автоматически отправляет заказ в API
```

## Что изменилось в Mini App

Добавлен новый способ оплаты:
- ⭐ **Telegram Stars** — оплата звёздами
- 💎 **Telegram Wallet** — оплата USDT/TON через Wallet Pay
- 💰 **CryptoBot / Вручную** — оплата USDT вручную

## Файлы которые были обновлены

| Файл | Изменения |
|------|----------|
| `src/pages/CheckoutPage.tsx` | + Wallet Pay radio button |
| `bot.py` | + Wallet Pay API интеграция |
| `api/wallet.ts` | Новый Wallet Pay API клиент |

## Альтернативы если Wallet Pay не настроен

Если не хотите настраивать Wallet Pay, можно использовать:
1. **Telegram Stars** — работает без настройки
2. **CryptoBot** — нужен токен от @CryptoBot
3. **Ручная оплата** — пользователь переводит вручную

## Поддержка

По вопросам: @adforce_support
