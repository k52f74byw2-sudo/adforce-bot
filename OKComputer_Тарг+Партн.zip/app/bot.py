#!/usr/bin/env python3
"""
AdForce Russia Bot — Telegram Mini App Backend
Handles orders from Mini App, processes payments (Stars + Wallet Pay + USDT),
and submits orders to stream-promotion.ru API.
"""

import os
import json
import logging
import asyncio
from datetime import datetime
from typing import Optional

import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# ── Configuration ─────────────────────────────────────────────────────────────
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw")
API_KEY = os.environ.get("STREAM_API_KEY", "roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY")
API_BASE = "https://stream-promotion.ru/api/v2"
MINI_APP_URL = os.environ.get("MINI_APP_URL", "https://kcgxjw54o6ji2.kimi.page")

CRYPTOBOT_TOKEN = os.environ.get("CRYPTOBOT_TOKEN", "")
WALLET_PAY_TOKEN = os.environ.get("WALLET_PAY_TOKEN", "")

logging.basicConfig(
    format="%(asctime)s — %(name)s — %(levelname)s — %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# In-memory order storage (use Redis/DB for production)
pending_orders = {}


# ── API Helpers ───────────────────────────────────────────────────────────────

async def api_request(action: str, **params) -> dict:
    """Make request to stream-promotion.ru API."""
    payload = {"key": API_KEY, "action": action, **params}
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(API_BASE, data=payload, timeout=30) as resp:
                data = await resp.json()
                return data
        except Exception as e:
            logger.error(f"API error ({action}): {e}")
            return {"error": str(e)}


# ── Wallet Pay API ───────────────────────────────────────────────────────────

WALLET_API = "https://pay.wallet.tg/wpay/store-api/v1"

async def create_wallet_invoice(amount: float, currency: str, description: str, external_id: str, return_url: str) -> dict:
    """Create invoice via Telegram Wallet Pay API."""
    if not WALLET_PAY_TOKEN:
        return {"error": "Wallet Pay not configured"}

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(
                f"{WALLET_API}/order",
                headers={
                    "Wpay-Store-Api-Key": WALLET_PAY_TOKEN,
                    "Content-Type": "application/json",
                },
                json={
                    "amount": {
                        "currencyCode": currency,
                        "amount": str(amount),
                    },
                    "externalId": external_id,
                    "timeoutSeconds": 3600,
                    "description": description,
                    "returnUrl": return_url,
                },
                timeout=30,
            ) as resp:
                return await resp.json()
        except Exception as e:
            logger.error(f"Wallet Pay error: {e}")
            return {"error": str(e)}


async def get_wallet_status(order_id: str) -> dict:
    """Get Wallet Pay invoice status."""
    if not WALLET_PAY_TOKEN:
        return {"error": "Wallet Pay not configured"}

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(
                f"{WALLET_API}/order?id={order_id}",
                headers={"Wpay-Store-Api-Key": WALLET_PAY_TOKEN},
                timeout=30,
            ) as resp:
                return await resp.json()
        except Exception as e:
            logger.error(f"Wallet status error: {e}")
            return {"error": str(e)}


# ── Command Handlers ──────────────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start — show welcome + open Mini App button."""
    user = update.effective_user

    welcome_text = (
        f"👋 *Привет, {user.first_name}!*\n\n"
        f"*AdForce* — ваш надежный партнер для продвижения в социальных сетях.\n\n"
        f"🚀 Мы предлагаем:\n"
        f"  • Реальные подписчики\n"
        f"  • Живые просмотры\n"
        f"  • Активные лайки и репосты\n\n"
        f"💎 Оплата: *Telegram Stars*, *Wallet Pay (USDT/TON)* или *Crypto*\n\n"
        f"Нажмите кнопку ниже, чтобы открыть приложение 👇"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(
            text="🚀 Открыть AdForce",
            web_app=WebAppInfo(url=MINI_APP_URL)
        )],
        [InlineKeyboardButton(
            text="💬 Поддержка",
            url="https://t.me/adforce_support"
        )],
    ])

    await update.message.reply_text(
        welcome_text,
        parse_mode="Markdown",
        reply_markup=keyboard,
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help."""
    text = (
        "*Как использовать AdForce:*\n\n"
        "1️⃣ Нажмите 🚀 *Открыть AdForce*\n"
        "2️⃣ Выберите платформу (YouTube, VK, Telegram...)\n"
        "3️⃣ Выберите нужную услугу\n"
        "4️⃣ Укажите количество\n"
        "5️⃣ Перейдите к оплате\n"
        "6️⃣ Выберите способ оплаты:\n"
        "   • Stars ⭐\n"
        "   • Wallet Pay (USDT/TON) 💎\n"
        "   • CryptoBot / Вручную 💰\n"
        "7️⃣ После оплаты заказ запустится автоматически!\n\n"
        "*Команды:*\n"
        "/start — Открыть приложение\n"
        "/status — Проверить статус заказа\n"
        "/balance — Проверить баланс\n"
        "/help — Помощь"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


async def balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /balance — show API balance."""
    msg = await update.message.reply_text("⏳ Проверяем баланс...")
    result = await api_request("balance")

    if "balance" in result:
        text = (
            f"💰 *Баланс аккаунта*\n\n"
            f"Доступно: *{result['balance']}* руб.\n"
            f"Валюта: {result.get('currency', 'RUB')}"
        )
    else:
        text = "❌ Не удалось получить баланс. Попробуйте позже."

    await msg.edit_text(text, parse_mode="Markdown")


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /status <order_id>."""
    args = context.args
    if not args:
        await update.message.reply_text(
            "📋 Укажите ID заказа: `/status 12345`",
            parse_mode="Markdown",
        )
        return

    order_id = args[0]
    msg = await update.message.reply_text(f"⏳ Проверяем статус заказа #{order_id}...")

    result = await api_request("status", order=order_id)

    if "status" in result:
        status_emoji = {
            "Pending": "⏳",
            "In progress": "🔄",
            "Processing": "🔄",
            "Completed": "✅",
            "Partial": "⚠️",
            "Canceled": "❌",
            "Fail": "❌",
        }.get(result["status"], "📋")

        text = (
            f"{status_emoji} *Заказ #{order_id}*\n\n"
            f"Статус: *{result['status']}*\n"
            f"Начальное количество: {result.get('start_count', 'N/A')}\n"
            f"Осталось: {result.get('remains', 'N/A')}"
        )
    else:
        text = f"❌ Заказ #{order_id} не найден или произошла ошибка."

    await msg.edit_text(text, parse_mode="Markdown")


# ── Web App Data Handler ──────────────────────────────────────────────────────

async def web_app_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process data received from Mini App."""
    data_str = update.effective_message.web_app_data.data
    user = update.effective_user
    chat_id = update.effective_chat.id

    logger.info(f"WebApp data from {user.id}: {data_str[:500]}")

    try:
        data = json.loads(data_str)
    except json.JSONDecodeError:
        await update.message.reply_text("❌ Ошибка: неверные данные от приложения.")
        return

    action = data.get("action")

    if action == "create_invoice":
        await process_invoice_request(update, context, data)
    else:
        await update.message.reply_text(f"⚠️ Неизвестное действие: {action}")


async def process_invoice_request(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    data: dict,
):
    """Create invoice for payment."""
    user = update.effective_user
    chat_id = update.effective_chat.id
    method = data.get("method")
    amount = data.get("amount")
    currency = data.get("currency")
    rub_total = data.get("rubTotal")
    items = data.get("items", [])

    # Generate order reference
    order_ref = f"AF{user.id}_{int(datetime.now().timestamp())}"

    # Store pending order
    pending_orders[order_ref] = {
        "user_id": user.id,
        "chat_id": chat_id,
        "method": method,
        "amount": amount,
        "currency": currency,
        "rub_total": rub_total,
        "items": items,
        "link": data.get("link", ""),
        "status": "pending",
        "created_at": datetime.now().isoformat(),
        "api_orders": [],
    }

    # Build order summary
    items_text = "\n".join(
        f"  • {item.get('name', 'Услуга')} × {item.get('qty', 1)}"
        for item in items
    )

    # Build button text based on method
    if method == "stars":
        btn_text = f"⭐ Оплатить {amount:,.0f} Stars"
    elif method == "wallet":
        btn_text = f"💎 Оплатить через Wallet ({amount:.2f} USDT)"
    else:
        btn_text = f"💰 Оплатить {amount:.2f} USDT"

    invoice_text = (
        f"📦 *Новый заказ #{order_ref}*\n\n"
        f"🛒 *Услуги:*\n{items_text}\n\n"
        f"💵 *Сумма:* {rub_total:.0f} ₽\n"
        f"💎 *К оплате:* {amount:,.0f if method == 'stars' else f'{amount:.2f}'}{' ⭐' if method == 'stars' else f' {currency}'}\n\n"
        f"Выберите действие:"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(text=btn_text, callback_data=f"pay:{order_ref}")],
        [InlineKeyboardButton(text="❌ Отменить", callback_data=f"cancel:{order_ref}")],
    ])

    await update.message.reply_text(
        invoice_text,
        parse_mode="Markdown",
        reply_markup=keyboard,
    )


# ── Callback Query Handlers ───────────────────────────────────────────────────

async def payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment/cancel callbacks."""
    query = update.callback_query
    await query.answer()

    data = query.data
    action, order_ref = data.split(":", 1)

    order = pending_orders.get(order_ref)
    if not order:
        await query.edit_message_text("❌ Заказ не найден или устарел.")
        return

    if action == "cancel":
        order["status"] = "canceled"
        await query.edit_message_text("❌ Заказ отменен.")
        return

    if action == "pay":
        if order["method"] == "stars":
            await process_stars_payment(query, order_ref, order)
        elif order["method"] == "wallet":
            await process_wallet_payment(query, order_ref, order)
        elif order["method"] == "crypto":
            await process_usdt_payment(query, order_ref, order)


async def process_stars_payment(query, order_ref: str, order: dict):
    """Send Telegram Stars invoice."""
    chat_id = order["chat_id"]
    amount = int(order["amount"])

    items_desc = ", ".join(
        f"{item.get('name', 'Услуга')} x{item.get('qty', 1)}"
        for item in order["items"]
    )[:200]

    await query.edit_message_text(
        f"⏳ Создаем счет на оплату Stars...\n\n"
        f"Сумма: *{amount:,}* ⭐",
        parse_mode="Markdown",
    )

    try:
        await query.bot.send_invoice(
            chat_id=chat_id,
            title=f"AdForce — Заказ #{order_ref}",
            description=items_desc or "Продвижение в социальных сетях",
            payload=order_ref,
            provider_token="",
            currency="XTR",
            prices=[{"label": "Услуги продвижения", "amount": amount}],
        )
        logger.info(f"Stars invoice sent for {order_ref}, amount={amount}")
    except Exception as e:
        logger.error(f"Failed to send Stars invoice: {e}")
        await query.bot.send_message(chat_id=chat_id, text=f"❌ Ошибка: {e}")


async def process_wallet_payment(query, order_ref: str, order: dict):
    """Create Wallet Pay invoice."""
    chat_id = order["chat_id"]
    amount = float(order["amount"])
    currency = order.get("currency", "USDT")

    await query.edit_message_text(
        f"⏳ Создаем счет через Wallet Pay...\n\n"
        f"Сумма: *{amount:.2f}* {currency}",
        parse_mode="Markdown",
    )

    items_desc = ", ".join(
        f"{item.get('name', 'Услуга')}"
        for item in order["items"]
    )[:100]

    result = await create_wallet_invoice(
        amount=amount,
        currency=currency,
        description=items_desc or f"AdForce Order #{order_ref}",
        external_id=order_ref,
        return_url=f"https://t.me/{(await query.bot.get_me()).username}",
    )

    if "error" in result:
        error_msg = result["error"]
        logger.error(f"Wallet Pay error: {error_msg}")

        # Fallback to manual instructions
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(text="✅ Я оплатил", callback_data=f"usdt_paid:{order_ref}")],
            [InlineKeyboardButton(text="❌ Отменить", callback_data=f"cancel:{order_ref}")],
        ])

        await query.edit_message_text(
            f"💎 *Оплата через Telegram Wallet*\n\n"
            f"⚠️ Wallet Pay API временно недоступен.\n\n"
            f"Сумма к оплате: *{amount:.2f} {currency}*\n\n"
            f"1️⃣ Откройте @wallet\n"
            f"2️⃣ Выберите 'Перевод'\n"
            f"3️⃣ Отправьте *{amount:.2f} {currency}*\n"
            f"4️⃣ Нажмите ✅ *Я оплатил*",
            parse_mode="Markdown",
            reply_markup=keyboard,
        )
        return

    if result.get("status") == "SUCCESS" and result.get("data"):
        pay_link = result["data"].get("payLink") or result["data"].get("directPayLink")
        wallet_order_id = result["data"].get("id")

        if pay_link:
            order["wallet_order_id"] = wallet_order_id

            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(text=f"💎 Оплатить {amount:.2f} {currency}", url=pay_link)],
                [InlineKeyboardButton(text="✅ Проверить оплату", callback_data=f"wallet_check:{order_ref}")],
                [InlineKeyboardButton(text="❌ Отменить", callback_data=f"cancel:{order_ref}")],
            ])

            await query.edit_message_text(
                f"💎 *Счет через Wallet Pay создан*\n\n"
                f"Сумма: *{amount:.2f} {currency}*\n"
                f"Заказ: `#{order_ref}`\n\n"
                f"Нажмите кнопку ниже для оплаты.\n"
                f"После оплаты нажмите 'Проверить оплату'.",
                parse_mode="Markdown",
                reply_markup=keyboard,
            )
            logger.info(f"Wallet invoice created: {wallet_order_id}")
            return

    # Fallback
    await query.edit_message_text(
        f"❌ Не удалось создать счет через Wallet Pay.\n"
        f"Попробуйте оплатить через Stars или свяжитесь с поддержкой."
    )


async def process_usdt_payment(query, order_ref: str, order: dict):
    """Process USDT payment via CryptoBot or manual instructions."""
    chat_id = order["chat_id"]
    amount = order["amount"]

    if CRYPTOBOT_TOKEN:
        await create_cryptobot_invoice(query, order_ref, order)
    else:
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(text="✅ Я оплатил", callback_data=f"usdt_paid:{order_ref}")],
            [InlineKeyboardButton(text="❌ Отменить", callback_data=f"cancel:{order_ref}")],
        ])

        await query.edit_message_text(
            f"💰 *Оплата USDT*\n\n"
            f"Сумма к оплате: *{amount:.2f} USDT*\n\n"
            f"Отправьте *{amount:.2f} USDT* на один из адресов:\n\n"
            f"🔹 *TRC20:* `TYRDMpH7q1A8z4MQ7BmQ1Gq7j1n4...`\n"
            f"🔹 *BEP20:* `0x742d35Cc6634C0532925a3b8D4e6D...`\n\n"
            f"После оплаты нажмите ✅ *Я оплатил*",
            parse_mode="Markdown",
            reply_markup=keyboard,
        )


async def wallet_check_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check Wallet Pay payment status."""
    query = update.callback_query
    await query.answer()

    order_ref = query.data.split(":", 1)[1]
    order = pending_orders.get(order_ref)

    if not order:
        await query.edit_message_text("❌ Заказ не найден.")
        return

    wallet_order_id = order.get("wallet_order_id")
    if not wallet_order_id:
        await query.edit_message_text("❌ ID заказа Wallet Pay не найден.")
        return

    await query.edit_message_text("⏳ Проверяем статус оплаты...")

    result = await get_wallet_status(wallet_order_id)

    if result.get("status") == "SUCCESS" and result.get("data"):
        status = result["data"].get("status")

        if status == "PAID":
            order["status"] = "paid"
            paid_amount = result["data"].get("paidAmount", {})

            await query.edit_message_text(
                f"✅ *Оплата получена!*\n\n"
                f"Сумма: *{paid_amount.get('amount', '?')} {paid_amount.get('currencyCode', 'USDT')}*\n"
                f"Заказ: #{order_ref}\n\n"
                f"🚀 Запускаем выполнение..."
            )

            await submit_orders_to_api(context, order_ref, order)
        elif status == "EXPIRED":
            await query.edit_message_text(
                f"⏰ *Счет истёк*\n\n"
                f"Заказ #{order_ref} больше не активен.\n"
                f"Создайте новый заказ в Mini App."
            )
        elif status == "PENDING":
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(text="🔄 Проверить снова", callback_data=f"wallet_check:{order_ref}")],
            ])

            await query.edit_message_text(
                f"⏳ *Ожидание оплаты*\n\n"
                f"Счет #{order_ref} ещё не оплачен.\n"
                f"Нажмите кнопку для повторной проверки.",
                reply_markup=keyboard,
            )
        else:
            await query.edit_message_text(f"📋 Статус: {status}")
    else:
        await query.edit_message_text("❌ Не удалось проверить статус. Попробуйте позже.")


async def create_cryptobot_invoice(query, order_ref: str, order: dict):
    """Create invoice via CryptoBot API."""
    import aiohttp

    amount = order["amount"]

    async with aiohttp.ClientSession() as session:
        headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}
        payload = {
            "asset": "USDT",
            "amount": str(amount),
            "description": f"AdForce Order #{order_ref}",
            "payload": order_ref,
            "paid_btn_name": "callback",
            "paid_btn_url": f"https://t.me/{(await query.bot.get_me()).username}",
        }

        try:
            async with session.post(
                "https://pay.crypt.bot/api/createInvoice",
                headers=headers,
                json=payload,
            ) as resp:
                result = await resp.json()

                if result.get("ok"):
                    invoice = result["result"]
                    pay_url = invoice["pay_url"]

                    keyboard = InlineKeyboardMarkup([
                        [InlineKeyboardButton(text="💰 Оплатить USDT", url=pay_url)],
                    ])

                    await query.edit_message_text(
                        f"💰 *Счет на оплату создан*\n\n"
                        f"Сумма: *{amount:.2f} USDT*\n"
                        f"Нажмите кнопку ниже для оплаты 👇",
                        parse_mode="Markdown",
                        reply_markup=keyboard,
                    )
                else:
                    await query.edit_message_text(
                        f"❌ Ошибка CryptoBot: {result.get('error', 'Unknown')}"
                    )
        except Exception as e:
            logger.error(f"CryptoBot error: {e}")
            await query.edit_message_text(f"❌ Ошибка: {e}")


async def usdt_paid_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle manual USDT payment confirmation."""
    query = update.callback_query
    await query.answer()

    order_ref = query.data.split(":", 1)[1]
    order = pending_orders.get(order_ref)

    if not order:
        await query.edit_message_text("❌ Заказ не найден.")
        return

    await query.edit_message_text(
        f"⏳ Проверяем оплату заказа #{order_ref}...\n"
        f"Наш менеджер проверит транзакцию вручную.\n\n"
        f"Обычно это занимает 5-15 минут."
    )


# ── Pre-checkout & Successful Payment ─────────────────────────────────────────

async def precheckout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Telegram pre-checkout query."""
    query = update.pre_checkout_query
    order_ref = query.invoice_payload

    if order_ref in pending_orders:
        await query.answer(ok=True)
        logger.info(f"Pre-checkout OK for {order_ref}")
    else:
        await query.answer(ok=False, error_message="Заказ не найден.")


async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle successful Telegram Stars payment."""
    payment = update.message.successful_payment
    order_ref = payment.invoice_payload
    user = update.effective_user

    logger.info(f"Stars payment success: {order_ref}, amount={payment.total_amount}")

    order = pending_orders.get(order_ref)
    if not order:
        await update.message.reply_text("⚠️ Заказ не найден.")
        return

    order["status"] = "paid"

    await update.message.reply_text(
        f"✅ *Оплата Stars получена!*\n\n"
        f"Заказ: *#{order_ref}*\n"
        f"Сумма: *{payment.total_amount:,}* ⭐\n\n"
        f"🚀 Запускаем выполнение...",
        parse_mode="Markdown",
    )

    await submit_orders_to_api(context, order_ref, order)


# ── API Order Submission ──────────────────────────────────────────────────────

async def submit_orders_to_api(
    context: ContextTypes.DEFAULT_TYPE,
    order_ref: str,
    order: dict,
):
    """Submit each service to stream-promotion.ru API."""
    items = order.get("items", [])
    api_orders = []

    for item in items:
        service_id = item.get("service")
        qty = item.get("qty", 1)

        result = await api_request(
            "add",
            service=service_id,
            quantity=qty,
            link=order.get("link", ""),
        )

        api_orders.append({
            "service": service_id,
            "qty": qty,
            "result": result,
        })

        await asyncio.sleep(0.5)

    order["api_orders"] = api_orders
    order["status"] = "submitted"

    success_count = sum(1 for o in api_orders if "order" in o["result"])
    failed_count = len(api_orders) - success_count

    result_lines = []
    for o in api_orders:
        if "order" in o["result"]:
            result_lines.append(f"  ✅ ID {o['result']['order']}")
        else:
            error = o["result"].get("error", "Unknown error")
            result_lines.append(f"  ❌ Ошибка: {error}")

    status_text = (
        f"📊 *Результат #{order_ref}*\n\n"
        f"Успешно: *{success_count}* | Ошибок: *{failed_count}*\n\n"
        f"{'\n'.join(result_lines)}\n\n"
        f"Проверить статус: /status `<order_id>`"
    )

    await context.bot.send_message(
        chat_id=order["chat_id"],
        text=status_text,
        parse_mode="Markdown",
    )


# ── Error Handler ─────────────────────────────────────────────────────────────

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Log errors."""
    logger.error(f"Update {update} caused error: {context.error}")


# ── Main ──────────────────────────────────────────────────────────────────────

async def post_init(app: Application):
    """Set bot commands."""
    await app.bot.set_my_commands([
        ("start", "Открыть приложение"),
        ("balance", "Проверить баланс"),
        ("status", "Проверить статус заказа"),
        ("help", "Помощь"),
    ])
    logger.info("Bot initialized, commands set.")


def main():
    """Build and run the bot."""
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # Commands
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_cmd))
    application.add_handler(CommandHandler("balance", balance_cmd))
    application.add_handler(CommandHandler("status", status_cmd))

    # Web App data
    application.add_handler(
        MessageHandler(filters.StatusUpdate.WEB_APP_DATA, web_app_data)
    )

    # Callbacks
    application.add_handler(CallbackQueryHandler(payment_callback, pattern=r"^(pay|cancel):"))
    application.add_handler(CallbackQueryHandler(wallet_check_callback, pattern=r"^wallet_check:"))
    application.add_handler(CallbackQueryHandler(usdt_paid_callback, pattern=r"^usdt_paid:"))

    # Payments
    application.add_handler(PreCheckoutQueryHandler(precheckout))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))

    # Errors
    application.add_error_handler(error_handler)

    logger.info("Bot starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
