#!/usr/bin/env bash
# ── Heroku Deployment Script for AdForce Bot ──────────────────────────────────
# Usage: bash deploy_heroku.sh YOUR_APP_NAME

set -e

APP_NAME="${1:-adforce-russia-bot}"

echo "═══════════════════════════════════════════════════════════"
echo "  AdForce Russia Bot — Heroku Deployment"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Check prerequisites
check_cmd() {
    if ! command -v "$1" &> /dev/null; then
        echo "❌ $1 is not installed. Please install it first."
        exit 1
    fi
    echo "✅ $1 found"
}

check_cmd git
check_cmd heroku

echo ""
echo "App name: $APP_NAME"
echo ""

# Login to Heroku
echo "🔐 Checking Heroku login..."
heroku auth:whoami &>/dev/null || heroku login

# Create Heroku app if doesn't exist
echo ""
echo "📦 Creating/configuring Heroku app..."
heroku create "$APP_NAME" 2>/dev/null || echo "App already exists, continuing..."

# Set environment variables
echo ""
echo "🔑 Setting environment variables..."
heroku config:set TELEGRAM_BOT_TOKEN="8959012165:AAEtoZshlEIaK1r_uXuT2WkuCouWiX7RsTw" --app "$APP_NAME"
heroku config:set STREAM_API_KEY="roSeR9B68ZQb3iSXnx0qNXJ5xjLO3kfY" --app "$APP_NAME"
heroku config:set MINI_APP_URL="https://kcgxjw54o6ji2.kimi.page" --app "$APP_NAME"

# Deploy
echo ""
echo "🚀 Deploying bot..."
git add -A
git commit -m "Deploy bot to Heroku - $(date)" 2>/dev/null || true
git push heroku main 2>/dev/null || git push heroku master 2>/dev/null || echo "Push may need manual handling"

# Scale worker
echo ""
echo "⚡ Scaling worker dyno..."
heroku ps:scale worker=1 --app "$APP_NAME"

# Show status
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ Deployment Complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "App:      https://dashboard.heroku.com/apps/$APP_NAME"
echo "Logs:     heroku logs --tail --app $APP_NAME"
echo ""
echo "To view logs:"
echo "  heroku logs --tail --app $APP_NAME"
echo ""
echo "To restart:"
echo "  heroku ps:restart worker --app $APP_NAME"
echo ""
echo "To stop:"
echo "  heroku ps:scale worker=0 --app $APP_NAME"
echo ""
